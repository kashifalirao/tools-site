'use client';

import Link from 'next/link';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            About Us
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Learn about Kashif Digital Tools Service and our mission to provide free, high-quality online tools for everyone
          </p>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="grid md:grid-cols-2 gap-8 items-center mb-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
              <p className="text-gray-700 mb-4">
                Kashif Digital Tools Service was founded with a simple yet powerful vision: to democratize access to professional-grade digital tools. In today's digital age, everyone deserves access to powerful tools without the burden of expensive subscriptions or complex software installations.
              </p>
              <p className="text-gray-700 mb-4">
                Our journey began when we realized that many small businesses, students, and individuals were struggling with basic digital tasks like PDF conversion, image optimization, and SEO analysis. We set out to create a comprehensive suite of free tools that would level the playing field.
              </p>
              <p className="text-gray-700">
                Today, we're proud to serve thousands of users worldwide with our collection of 10+ free digital tools, each designed with simplicity, efficiency, and reliability in mind.
              </p>
            </div>
            <div>
              <img
                src="https://readdy.ai/api/search-image?query=professional%20digital%20workspace%20with%20multiple%20monitors%20showing%20various%20online%20tools%2C%20modern%20office%20environment%2C%20person%20working%20on%20digital%20projects%2C%20clean%20and%20organized%20desk%20setup%2C%20blue%20and%20white%20color%20scheme%2C%20productivity%20and%20success%20theme&width=500&height=400&seq=about-img-001&orientation=landscape"
                alt="Digital Tools Workspace"
                className="w-full rounded-lg shadow-md object-cover object-top"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-target-line text-2xl text-blue-600"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Our Mission</h3>
              <p className="text-gray-600">
                To provide free, accessible, and powerful digital tools that enhance productivity and creativity for users worldwide.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-eye-line text-2xl text-green-600"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Our Vision</h3>
              <p className="text-gray-600">
                To become the world's most trusted platform for free online tools, empowering millions of users to achieve their goals.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-heart-line text-2xl text-purple-600"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Our Values</h3>
              <p className="text-gray-600">
                Accessibility, quality, security, and user-first design principles guide everything we do at Kashif Digital Tools.
              </p>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Why Choose Us?</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                  <i className="ri-check-line text-blue-600"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">100% Free Forever</h4>
                  <p className="text-gray-600 text-sm">All our tools are completely free with no hidden charges or premium upgrades required.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                  <i className="ri-shield-check-line text-green-600"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Privacy & Security</h4>
                  <p className="text-gray-600 text-sm">Your files are processed securely and automatically deleted after use.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                  <i className="ri-smartphone-line text-purple-600"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Mobile Friendly</h4>
                  <p className="text-gray-600 text-sm">All tools work perfectly on desktop, tablet, and mobile devices.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                  <i className="ri-customer-service-line text-orange-600"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">24/7 Support</h4>
                  <p className="text-gray-600 text-sm">Get help whenever you need it through our multiple contact channels.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Team Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">Meet Our Founder</h2>
          
          <div className="max-w-2xl mx-auto text-center">
            <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-user-line text-3xl text-blue-600"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Kashif Ahmed</h3>
            <p className="text-blue-600 mb-4">Founder & Lead Developer</p>
            <p className="text-gray-700 mb-6">
              With over 8 years of experience in web development and digital marketing, Kashif founded this platform to bridge the gap between expensive premium tools and free alternatives. His expertise in SEO, content creation, and user experience design drives our tool development process.
            </p>
            <div className="flex justify-center space-x-4">
              <a href="mailto:guestpost@smartsavezone.com" className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center hover:bg-blue-200 transition-colors cursor-pointer">
                <i className="ri-mail-line text-blue-600"></i>
              </a>
              <a href="https://wa.me/923126020316" className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center hover:bg-green-200 transition-colors cursor-pointer">
                <i className="ri-whatsapp-line text-green-600"></i>
              </a>
              <a href="#" className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center hover:bg-blue-200 transition-colors cursor-pointer">
                <i className="ri-linkedin-fill text-blue-600"></i>
              </a>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="bg-blue-600 rounded-xl p-8 text-white mb-8">
          <h2 className="text-2xl font-bold mb-8 text-center">Our Impact</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold mb-2">10+</div>
              <div className="text-blue-200">Free Tools</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">50K+</div>
              <div className="text-blue-200">Happy Users</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">100K+</div>
              <div className="text-blue-200">Files Processed</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">99.9%</div>
              <div className="text-blue-200">Uptime</div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Ready to Try Our Tools?</h2>
          <p className="text-gray-600 mb-6">
            Join thousands of satisfied users and boost your productivity with our free digital tools.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/tools"
              className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium whitespace-nowrap cursor-pointer"
            >
              Explore All Tools
            </Link>
            <Link
              href="/contact"
              className="border border-blue-600 text-blue-600 px-8 py-3 rounded-lg hover:bg-blue-50 transition-colors font-medium whitespace-nowrap cursor-pointer"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}