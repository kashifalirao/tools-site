'use client';

import { useState } from 'react';
import Link from 'next/link';

interface ThumbnailQuality {
  name: string;
  size: string;
  quality: string;
}

export default function YouTubeThumbnailDownloaderPage() {
  const [videoUrl, setVideoUrl] = useState('');
  const [videoId, setVideoId] = useState('');
  const [thumbnails, setThumbnails] = useState<ThumbnailQuality[]>([]);
  const [isExtracting, setIsExtracting] = useState(false);
  const [error, setError] = useState('');

  const extractVideoId = (url: string): string | null => {
    const patterns = [
      /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=|embed\/|v\/)?([a-zA-Z0-9_-]{11})/,
      /^[a-zA-Z0-9_-]{11}$/
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) {
        return match[1] || match[0];
      }
    }
    return null;
  };

  const getThumbnails = () => {
    if (!videoUrl.trim()) {
      setError('Please enter a YouTube video URL');
      return;
    }

    const extractedId = extractVideoId(videoUrl.trim());
    if (!extractedId) {
      setError('Invalid YouTube URL. Please check the URL format.');
      return;
    }

    setIsExtracting(true);
    setError('');
    setVideoId(extractedId);

    // Simulate loading
    setTimeout(() => {
      const thumbnailQualities: ThumbnailQuality[] = [
        {
          name: 'Max Resolution',
          size: '1280x720',
          quality: 'maxresdefault.jpg'
        },
        {
          name: 'High Quality',
          size: '480x360',
          quality: 'hqdefault.jpg'
        },
        {
          name: 'Medium Quality',
          size: '320x180',
          quality: 'mqdefault.jpg'
        },
        {
          name: 'Standard Definition',
          size: '120x90',
          quality: 'sddefault.jpg'
        },
        {
          name: 'Default',
          size: '120x90',
          quality: 'default.jpg'
        }
      ];

      setThumbnails(thumbnailQualities);
      setIsExtracting(false);
    }, 1500);
  };

  const downloadThumbnail = (quality: string, name: string) => {
    const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/${quality}`;
    
    // Create a temporary link to download the image
    const link = document.createElement('a');
    link.href = thumbnailUrl;
    link.download = `youtube-thumbnail-${videoId}-${quality}`;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const resetTool = () => {
    setVideoUrl('');
    setVideoId('');
    setThumbnails([]);
    setError('');
  };

  const sampleUrls = [
    'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    'https://youtu.be/dQw4w9WgXcQ',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'dQw4w9WgXcQ'
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Link href="/" className="hover:text-blue-600 cursor-pointer">Home</Link>
            <i className="ri-arrow-right-s-line"></i>
            <Link href="/tools" className="hover:text-blue-600 cursor-pointer">Tools</Link>
            <i className="ri-arrow-right-s-line"></i>
            <span className="text-gray-900">YouTube Thumbnail Downloader</span>
          </div>
        </nav>

        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-red-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="ri-image-line text-2xl text-red-600"></i>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            YouTube Thumbnail Downloader
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Download YouTube video thumbnails in all available sizes and resolutions. Get high-quality thumbnails instantly.
          </p>
        </div>

        {/* Tool Interface */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="max-w-2xl mx-auto">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Enter YouTube Video URL or Video ID
            </label>
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                value={videoUrl}
                onChange={(e) => setVideoUrl(e.target.value)}
                placeholder="https://www.youtube.com/watch?v=VIDEO_ID"
                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-red-500 focus:ring-2 focus:ring-red-200"
                onKeyPress={(e) => e.key === 'Enter' && getThumbnails()}
              />
              <button
                onClick={getThumbnails}
                disabled={isExtracting}
                className="bg-red-600 text-white px-8 py-3 rounded-lg hover:bg-red-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer"
              >
                {isExtracting ? 'Extracting...' : 'Get Thumbnails'}
              </button>
            </div>
            
            {error && (
              <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                <div className="text-red-700 text-sm">{error}</div>
              </div>
            )}

            {/* Sample URLs */}
            <div className="mt-6">
              <p className="text-sm font-medium text-gray-700 mb-3">Try Sample URLs:</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {sampleUrls.map((url, index) => (
                  <button
                    key={index}
                    onClick={() => setVideoUrl(url)}
                    className="text-left text-sm text-blue-600 hover:text-blue-700 p-3 rounded border border-blue-200 hover:border-blue-300 hover:bg-blue-50 transition-colors cursor-pointer"
                  >
                    {url}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Loading State */}
        {isExtracting && (
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8 text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <div className="animate-spin w-8 h-8 border-2 border-red-600 border-t-transparent rounded-full"></div>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Extracting Thumbnails</h3>
            <p className="text-gray-600">Getting all available thumbnail sizes...</p>
          </div>
        )}

        {/* Thumbnails Display */}
        {thumbnails.length > 0 && (
          <div className="space-y-8">
            {/* Video Info */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Available Thumbnails</h2>
                  <p className="text-gray-600">Video ID: {videoId}</p>
                </div>
                <button
                  onClick={resetTool}
                  className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors font-medium whitespace-nowrap cursor-pointer"
                >
                  <i className="ri-refresh-line mr-2"></i>
                  Get New Thumbnails
                </button>
              </div>
            </div>

            {/* Thumbnails Grid */}
            <div className="grid gap-6">
              {thumbnails.map((thumbnail, index) => {
                const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/${thumbnail.quality}`;
                return (
                  <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div className="p-6">
                      <div className="flex flex-col lg:flex-row gap-6">
                        {/* Thumbnail Preview */}
                        <div className="lg:w-1/2">
                          <div className="aspect-video bg-gray-200 rounded-lg overflow-hidden">
                            <img
                              src={thumbnailUrl}
                              alt={`${thumbnail.name} thumbnail`}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = 'https://readdy.ai/api/search-image?query=youtube%20video%20thumbnail%20placeholder%20gray%20background%20with%20play%20button%20icon%20center&width=480&height=360&seq=thumbnail-error&orientation=landscape';
                              }}
                            />
                          </div>
                        </div>

                        {/* Thumbnail Info and Download */}
                        <div className="lg:w-1/2 flex flex-col justify-center">
                          <div className="mb-4">
                            <h3 className="text-xl font-bold text-gray-900 mb-2">
                              {thumbnail.name}
                            </h3>
                            <div className="space-y-2 text-gray-600">
                              <div className="flex items-center space-x-2">
                                <i className="ri-aspect-ratio-line"></i>
                                <span>Resolution: {thumbnail.size}</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <i className="ri-file-line"></i>
                                <span>Format: JPEG</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <i className="ri-links-line"></i>
                                <span className="break-all text-sm">{thumbnailUrl}</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-col sm:flex-row gap-3">
                            <button
                              onClick={() => downloadThumbnail(thumbnail.quality, thumbnail.name)}
                              className="flex-1 bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 transition-colors font-medium whitespace-nowrap cursor-pointer"
                            >
                              <i className="ri-download-line mr-2"></i>
                              Download {thumbnail.size}
                            </button>
                            <button
                              onClick={() => window.open(thumbnailUrl, '_blank')}
                              className="flex-1 border border-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-colors font-medium whitespace-nowrap cursor-pointer"
                            >
                              <i className="ri-external-link-line mr-2"></i>
                              View Full Size
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Download All Button */}
            <div className="text-center">
              <button
                onClick={() => {
                  thumbnails.forEach((thumbnail, index) => {
                    setTimeout(() => {
                      downloadThumbnail(thumbnail.quality, thumbnail.name);
                    }, index * 500);
                  });
                }}
                className="bg-green-600 text-white px-8 py-4 rounded-lg hover:bg-green-700 transition-colors font-medium text-lg whitespace-nowrap cursor-pointer"
              >
                <i className="ri-download-2-line mr-2"></i>
                Download All Sizes
              </button>
            </div>
          </div>
        )}

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 my-12">
          <div className="text-center p-6">
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-hd-line text-xl text-red-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Multiple Resolutions</h3>
            <p className="text-sm text-gray-600">
              Download thumbnails in all available sizes from 120x90 to 1280x720
            </p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-speed-line text-xl text-green-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Instant Download</h3>
            <p className="text-sm text-gray-600">
              Get thumbnails immediately without any processing delays
            </p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-links-line text-xl text-blue-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Multiple URL Formats</h3>
            <p className="text-sm text-gray-600">
              Supports all YouTube URL formats and direct video IDs
            </p>
          </div>
        </div>

        {/* Guide Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            How to Use YouTube Thumbnail Downloader
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Supported URL Formats</h3>
              <div className="space-y-3">
                <div className="bg-gray-50 p-3 rounded-lg">
                  <code className="text-sm">https://www.youtube.com/watch?v=VIDEO_ID</code>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <code className="text-sm">https://youtu.be/VIDEO_ID</code>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <code className="text-sm">https://www.youtube.com/embed/VIDEO_ID</code>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <code className="text-sm">VIDEO_ID (11 characters)</code>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Available Resolutions</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="font-medium">Max Resolution</span>
                  <span className="text-sm text-gray-600">1280x720</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="font-medium">High Quality</span>
                  <span className="text-sm text-gray-600">480x360</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="font-medium">Medium Quality</span>
                  <span className="text-sm text-gray-600">320x180</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="font-medium">Standard</span>
                  <span className="text-sm text-gray-600">120x90</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Step-by-Step Guide</h3>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="font-bold text-red-600">1</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Copy URL</h4>
                <p className="text-sm text-gray-600">Copy the YouTube video URL from your browser</p>
              </div>
              <div className="text-center">
                <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="font-bold text-red-600">2</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Paste URL</h4>
                <p className="text-sm text-gray-600">Paste the URL in the input field above</p>
              </div>
              <div className="text-center">
                <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="font-bold text-red-600">3</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Get Thumbnails</h4>
                <p className="text-sm text-gray-600">Click the "Get Thumbnails" button</p>
              </div>
              <div className="text-center">
                <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="font-bold text-red-600">4</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Download</h4>
                <p className="text-sm text-gray-600">Choose your preferred size and download</p>
              </div>
            </div>
          </div>

          <div className="mt-8 p-6 bg-blue-50 rounded-lg">
            <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
              <i className="ri-information-line text-blue-600 mr-2"></i>
              Best Practices
            </h4>
            <ul className="text-gray-700 space-y-1 text-sm">
              <li>• Use Max Resolution (1280x720) for best quality</li>
              <li>• High Quality (480x360) is perfect for most web uses</li>
              <li>• Medium Quality (320x180) is good for small previews</li>
              <li>• Always check if the video has high-resolution thumbnails available</li>
              <li>• Some older videos may not have all resolution options</li>
            </ul>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h2>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Is it legal to download YouTube thumbnails?
              </h3>
              <p className="text-gray-700">
                Yes, YouTube thumbnails are publicly accessible and can be downloaded for personal use, educational purposes, or fair use. However, respect copyright laws and YouTube's terms of service.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Why can't I get the highest resolution thumbnail?
              </h3>
              <p className="text-gray-700">
                Not all videos have maximum resolution thumbnails. Older videos or videos from certain creators might only have lower resolution options available.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Can I use these thumbnails commercially?
              </h3>
              <p className="text-gray-700">
                Thumbnails are copyrighted content owned by the video creator. For commercial use, you should obtain permission from the video owner or ensure your use falls under fair use guidelines.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                What format are the downloaded thumbnails?
              </h3>
              <p className="text-gray-700">
                All YouTube thumbnails are downloaded in JPEG format, which is optimized for web display and provides good quality with reasonable file sizes.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Do I need to install any software?
              </h3>
              <p className="text-gray-700">
                No, this is a web-based tool that works directly in your browser. No downloads or installations required.
              </p>
            </div>
          </div>
        </div>

        {/* Related Tools */}
        <div className="bg-red-50 rounded-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Related Media Tools
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/tools/image-compressor" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-image-line text-orange-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">Image Compressor</div>
            </Link>

            <Link href="/tools/qr-generator" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-qr-code-line text-blue-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">QR Generator</div>
            </Link>

            <Link href="/tools/color-palette-generator" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-palette-line text-purple-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">Color Palette</div>
            </Link>

            <Link href="/tools" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-apps-line text-gray-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">All Tools</div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}