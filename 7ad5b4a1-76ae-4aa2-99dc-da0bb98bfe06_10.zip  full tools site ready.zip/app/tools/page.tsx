'use client';

import Link from 'next/link';
import { useState } from 'react';

const allTools = [
  {
    id: 'pdf-to-word',
    name: 'PDF to Word Converter',
    description: 'Convert PDF files to editable Word documents instantly',
    icon: 'ri-file-pdf-line',
    color: 'bg-red-100 text-red-600',
    category: 'Document',
    popular: true
  },
  {
    id: 'word-to-pdf',
    name: 'Word to PDF Converter',
    description: 'Convert Word documents to PDF format easily',
    icon: 'ri-file-word-line',
    color: 'bg-blue-100 text-blue-600',
    category: 'Document',
    popular: true
  },
  {
    id: 'image-compressor',
    name: 'Image Compressor',
    description: 'Compress images without losing quality, reduce file size',
    icon: 'ri-image-line',
    color: 'bg-green-100 text-green-600',
    category: 'Image',
    popular: true
  },
  {
    id: 'backlink-checker',
    name: 'Backlink Checker',
    description: 'Analyze your website backlinks and SEO performance',
    icon: 'ri-links-line',
    color: 'bg-blue-100 text-blue-600',
    category: 'SEO',
    popular: true
  },
  {
    id: 'domain-authority-checker',
    name: 'Domain Authority Checker',
    description: 'Check DA/PA scores and domain metrics',
    icon: 'ri-global-line',
    color: 'bg-purple-100 text-purple-600',
    category: 'SEO',
    popular: false
  },
  {
    id: 'plagiarism-checker',
    name: 'Plagiarism Checker',
    description: 'Check content originality and detect duplicate text',
    icon: 'ri-shield-check-line',
    color: 'bg-teal-100 text-teal-600',
    category: 'Content',
    popular: false
  },
  {
    id: 'text-to-speech',
    name: 'Text to Speech',
    description: 'Convert text to natural-sounding speech with AI voices',
    icon: 'ri-volume-up-line',
    color: 'bg-orange-100 text-orange-600',
    category: 'Content',
    popular: true
  },
  {
    id: 'qr-generator',
    name: 'QR Code Generator',
    description: 'Create custom QR codes for URLs, text, and contact info',
    icon: 'ri-qr-code-line',
    color: 'bg-purple-100 text-purple-600',
    category: 'Utility',
    popular: true
  },
  {
    id: 'youtube-thumbnail-downloader',
    name: 'YouTube Thumbnail Downloader',
    description: 'Download high-quality YouTube video thumbnails',
    icon: 'ri-youtube-line',
    color: 'bg-red-100 text-red-600',
    category: 'Utility',
    popular: false
  },
  {
    id: 'meta-tags-extractor',
    name: 'Meta Tags Extractor',
    description: 'Extract title, meta description, and H1 tags from URLs',
    icon: 'ri-code-line',
    color: 'bg-indigo-100 text-indigo-600',
    category: 'SEO',
    popular: false
  }
];

export default function ToolsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  
  const categories = ['All', 'Document', 'Image', 'SEO', 'Content', 'Utility'];
  
  const filteredTools = allTools.filter(tool => {
    const matchesSearch = tool.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tool.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || tool.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            All Digital Tools
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Complete collection of free online tools for productivity, SEO, content creation, and more
          </p>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1">
              <div className="relative">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search tools..."
                  className="w-full px-4 py-3 pl-12 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                />
                <div className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                  <i className="ri-search-line text-gray-400"></i>
                </div>
              </div>
            </div>

            {/* Categories */}
            <div className="flex flex-wrap gap-2">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
                    selectedCategory === category
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTools.map((tool) => (
            <Link
              key={tool.id}
              href={`/tools/${tool.id}`}
              className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden group cursor-pointer"
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 ${tool.color} rounded-lg flex items-center justify-center`}>
                    <i className={`${tool.icon} text-xl`}></i>
                  </div>
                  {tool.popular && (
                    <span className="bg-orange-100 text-orange-600 text-xs px-2 py-1 rounded-full font-medium">
                      Popular
                    </span>
                  )}
                </div>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                  {tool.name}
                </h3>
                <p className="text-gray-600 mb-4 text-sm">
                  {tool.description}
                </p>
                
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                    {tool.category}
                  </span>
                  <div className="flex items-center text-blue-600 font-medium text-sm">
                    Use Tool
                    <div className="w-4 h-4 ml-1 flex items-center justify-center">
                      <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform"></i>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {filteredTools.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-search-line text-2xl text-gray-400"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No tools found</h3>
            <p className="text-gray-600">Try adjusting your search or filter criteria</p>
          </div>
        )}
      </div>
    </div>
  );
}