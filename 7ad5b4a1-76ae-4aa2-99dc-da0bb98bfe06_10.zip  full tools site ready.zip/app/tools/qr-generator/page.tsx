'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function QRGeneratorPage() {
  const [text, setText] = useState('');
  const [qrType, setQrType] = useState('url');
  const [qrUrl, setQrUrl] = useState('');
  const [size, setSize] = useState(200);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateQR = () => {
    if (!text.trim()) return;
    
    setIsGenerating(true);
    const qrData = encodeURIComponent(text);
    const newQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${qrData}&format=png`;
    setQrUrl(newQrUrl);
    setIsGenerating(false);
  };

  const downloadQR = () => {
    if (!qrUrl) return;
    
    const link = document.createElement('a');
    link.href = qrUrl;
    link.download = `qr-code-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const presetTexts = {
    url: 'https://example.com',
    text: 'Hello World! This is a QR code with custom text.',
    email: 'mailto:contact@example.com',
    phone: 'tel:+1234567890',
    wifi: 'WIFI:T:WPA;S:NetworkName;P:password123;H:false;;',
    contact: 'BEGIN:VCARD\nVERSION:3.0\nFN:John Doe\nTEL:+1234567890\nEMAIL:john@example.com\nEND:VCARD'
  };

  const handleTypeChange = (type: string) => {
    setQrType(type);
    setText(presetTexts[type as keyof typeof presetTexts] || '');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="ri-qr-code-line text-3xl text-purple-600"></i>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Free QR Code Generator
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Create custom QR codes for URLs, text, contact info, WiFi, and more. Download high-quality PNG images instantly.
          </p>
        </div>

        {/* Main Tool */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Input Section */}
            <div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  QR Code Type
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries({
                    url: { label: 'Website URL', icon: 'ri-global-line' },
                    text: { label: 'Plain Text', icon: 'ri-text' },
                    email: { label: 'Email', icon: 'ri-mail-line' },
                    phone: { label: 'Phone', icon: 'ri-phone-line' },
                    wifi: { label: 'WiFi', icon: 'ri-wifi-line' },
                    contact: { label: 'Contact Card', icon: 'ri-contacts-line' }
                  }).map(([key, { label, icon }]) => (
                    <button
                      key={key}
                      onClick={() => handleTypeChange(key)}
                      className={`p-3 rounded-lg border text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                        qrType === key
                          ? 'bg-purple-600 text-white border-purple-600'
                          : 'bg-white text-gray-700 border-gray-300 hover:border-purple-300'
                      }`}
                    >
                      <div className="flex flex-col items-center">
                        <i className={`${icon} text-lg mb-1`}></i>
                        {label}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Content
                </label>
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Enter your content here..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-200 resize-none"
                  rows={6}
                  maxLength={2000}
                />
                <div className="text-sm text-gray-500 mt-1">
                  {text.length}/2000 characters
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Size: {size}x{size} pixels
                </label>
                <input
                  type="range"
                  min="100"
                  max="500"
                  value={size}
                  onChange={(e) => setSize(Number(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-500 mt-1">
                  <span>100px</span>
                  <span>500px</span>
                </div>
              </div>

              <button
                onClick={generateQR}
                disabled={!text.trim() || isGenerating}
                className="w-full bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed font-semibold whitespace-nowrap cursor-pointer"
              >
                {isGenerating ? 'Generating...' : 'Generate QR Code'}
              </button>
            </div>

            {/* Output Section */}
            <div className="flex flex-col items-center justify-center">
              {qrUrl ? (
                <div className="text-center">
                  <div className="bg-white p-4 rounded-xl shadow-lg mb-6">
                    <img
                      src={qrUrl}
                      alt="Generated QR Code"
                      className="max-w-full h-auto"
                      style={{ width: `${Math.min(size, 300)}px` }}
                    />
                  </div>
                  <button
                    onClick={downloadQR}
                    className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors font-semibold whitespace-nowrap cursor-pointer"
                  >
                    <i className="ri-download-line mr-2"></i>
                    Download QR Code
                  </button>
                </div>
              ) : (
                <div className="text-center text-gray-500">
                  <div className="w-32 h-32 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-qr-code-line text-4xl"></i>
                  </div>
                  <p>Enter content and click "Generate QR Code"</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Related Tools */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Related Tools</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link href="/tools/image-compressor" className="p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <i className="ri-image-line text-green-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Image Compressor</div>
                  <div className="text-sm text-gray-600">Compress images</div>
                </div>
              </div>
            </Link>
            <Link href="/tools/pdf-to-word" className="p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                  <i className="ri-file-pdf-line text-red-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">PDF to Word</div>
                  <div className="text-sm text-gray-600">Convert documents</div>
                </div>
              </div>
            </Link>
            <Link href="/tools/backlink-checker" className="p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <i className="ri-links-line text-blue-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Backlink Checker</div>
                  <div className="text-sm text-gray-600">SEO analysis</div>
                </div>
              </div>
            </Link>
          </div>
        </div>

        {/* Article Content */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <article className="prose max-w-none">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Complete Guide to QR Code Generation</h2>
            
            <p className="text-lg text-gray-700 mb-6">
              QR codes have revolutionized how we share information quickly and efficiently. Our free QR code generator allows you to create custom QR codes for various purposes including websites, contact information, WiFi passwords, and plain text.
            </p>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">What Can You Create?</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mt-1">
                    <i className="ri-global-line text-blue-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Website URLs</h4>
                    <p className="text-gray-600 text-sm">Direct users to your website or specific pages instantly.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mt-1">
                    <i className="ri-mail-line text-green-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Email Contacts</h4>
                    <p className="text-gray-600 text-sm">Allow quick email composition with pre-filled addresses.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mt-1">
                    <i className="ri-wifi-line text-purple-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">WiFi Access</h4>
                    <p className="text-gray-600 text-sm">Share WiFi credentials without revealing passwords.</p>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center mt-1">
                    <i className="ri-phone-line text-orange-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Phone Numbers</h4>
                    <p className="text-gray-600 text-sm">Enable instant calling with a simple scan.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center mt-1">
                    <i className="ri-contacts-line text-red-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Contact Cards</h4>
                    <p className="text-gray-600 text-sm">Share complete contact information via vCard format.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-teal-100 rounded-lg flex items-center justify-center mt-1">
                    <i className="ri-text text-teal-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Plain Text</h4>
                    <p className="text-gray-600 text-sm">Display any custom message or information.</p>
                  </div>
                </div>
              </div>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Best Practices for QR Codes</h3>
            <div className="bg-gray-50 p-6 rounded-lg mb-6">
              <ul className="space-y-3">
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Keep content concise and relevant for better scanning</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Use appropriate size (minimum 2cm x 2cm for print)</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Ensure high contrast between code and background</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Test your QR code before final use</span>
                </li>
              </ul>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Common Use Cases</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-blue-50 p-6 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">Business Cards</h4>
                <p className="text-blue-800 text-sm">Add QR codes to business cards for instant contact sharing</p>
              </div>
              <div className="bg-green-50 p-6 rounded-lg">
                <h4 className="font-semibold text-green-900 mb-2">Restaurant Menus</h4>
                <p className="text-green-800 text-sm">Provide contactless menu access for customers</p>
              </div>
              <div className="bg-purple-50 p-6 rounded-lg">
                <h4 className="font-semibold text-purple-900 mb-2">Event Registration</h4>
                <p className="text-purple-800 text-sm">Simplify event check-ins and registration processes</p>
              </div>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Frequently Asked Questions</h3>
            <div className="space-y-6">
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">Are QR codes free to create and use?</h4>
                <p className="text-gray-700">Yes, our QR code generator is completely free with no limitations. You can create and download as many QR codes as needed.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">What's the maximum amount of data a QR code can store?</h4>
                <p className="text-gray-700">QR codes can store up to 2,953 bytes of data, which translates to about 2,000 characters of text, depending on the character type.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">Can QR codes expire?</h4>
                <p className="text-gray-700">Static QR codes (like ours) never expire. However, if the content they link to becomes unavailable, the QR code won't work.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">What image formats are supported for download?</h4>
                <p className="text-gray-700">Currently, we provide QR codes in PNG format, which offers excellent quality and compatibility across all platforms and devices.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">Can I customize the colors of my QR code?</h4>
                <p className="text-gray-700">Our current version generates standard black and white QR codes, which ensure maximum compatibility and readability across all QR code readers.</p>
              </div>
            </div>
          </article>
        </div>
      </div>
    </div>
  );
}