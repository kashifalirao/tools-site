
'use client';

import { useState, useRef } from 'react';
import Link from 'next/link';

export default function PDFToWordPage() {
  const [file, setFile] = useState<File | null>(null);
  const [isConverting, setIsConverting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [convertedFile, setConvertedFile] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (selectedFile: File) => {
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setConvertedFile(null);
    } else {
      alert('Please select a valid PDF file.');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      handleFileSelect(droppedFile);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      handleFileSelect(selectedFile);
    }
  };

  const convertToWord = async () => {
    if (!file) return;
    
    setIsConverting(true);
    setProgress(0);
    
    // Simulate conversion process
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + 10;
      });
    }, 200);

    // Simulate conversion delay
    setTimeout(() => {
      setProgress(100);
      setIsConverting(false);
      setConvertedFile(`${file.name.replace('.pdf', '')}.docx`);
      clearInterval(interval);
    }, 3000);
  };

  const downloadWord = () => {
    if (!convertedFile) return;
    
    // Create a blob for demo purposes
    const demoContent = `Converted Word document: ${convertedFile}\\nOriginal PDF: ${file?.name}\\nConversion completed successfully!`;
    const blob = new Blob([demoContent], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = convertedFile;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const resetTool = () => {
    setFile(null);
    setConvertedFile(null);
    setIsConverting(false);
    setProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-red-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="ri-file-pdf-line text-3xl text-red-600"></i>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            PDF to Word Converter
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Convert PDF files to editable Word documents instantly. Upload your PDF and get a fully editable .docx file in seconds.
          </p>
        </div>

        {/* Main Tool */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          {!convertedFile ? (
            <>
              {/* File Upload Area */}
              <div
                onDrop={handleDrop}
                onDragOver={(e) => e.preventDefault()}
                onDragEnter={(e) => e.preventDefault()}
                className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-red-400 transition-colors"
              >
                {!file ? (
                  <div>
                    <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-file-pdf-line text-2xl text-red-600"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Select PDF File
                    </h3>
                    <p className="text-gray-600 mb-6">
                      Drag and drop your PDF file here, or click to browse
                    </p>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".pdf"
                      onChange={handleFileInput}
                      className="hidden"
                      id="file-upload"
                    />
                    <label
                      htmlFor="file-upload"
                      className="bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 transition-colors cursor-pointer inline-block whitespace-nowrap"
                    >
                      Select PDF File
                    </label>
                    <p className="text-sm text-gray-500 mt-4">
                      Supported format: PDF (Maximum file size: 10MB)
                    </p>
                  </div>
                ) : (
                  <div>
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-check-line text-2xl text-green-600"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      File Ready
                    </h3>
                    <p className="text-gray-600 mb-2">
                      {file.name}
                    </p>
                    <p className="text-sm text-gray-500 mb-6">
                      Size: {(file.size / (1024 * 1024)).toFixed(2)} MB
                    </p>
                    
                    {!isConverting ? (
                      <div className="flex justify-center space-x-4">
                        <button
                          onClick={convertToWord}
                          className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors font-semibold whitespace-nowrap cursor-pointer"
                        >
                          <i className="ri-file-word-line mr-2"></i>
                          Convert to Word
                        </button>
                        <button
                          onClick={resetTool}
                          className="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors font-semibold whitespace-nowrap cursor-pointer"
                        >
                          Choose Different File
                        </button>
                      </div>
                    ) : (
                      <div className="max-w-md mx-auto">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-gray-600">Converting...</span>
                          <span className="text-sm text-gray-600">{progress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-3">
                          <div
                            className="bg-red-600 h-3 rounded-full transition-all duration-300"
                            style={{ width: `${progress}%` }}
                          ></div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </>
          ) : (
            /* Success State */
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-check-double-line text-3xl text-green-600"></i>
              </div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-4">
                Conversion Complete!
              </h3>
              <p className="text-gray-600 mb-8">
                Your PDF has been successfully converted to an editable Word document.
              </p>
              
              <div className="bg-gray-50 rounded-lg p-6 mb-8">
                <div className="flex items-center justify-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <i className="ri-file-pdf-line text-red-600 text-xl"></i>
                    <span className="text-gray-700">{file?.name}</span>
                  </div>
                  <i className="ri-arrow-right-line text-gray-400"></i>
                  <div className="flex items-center space-x-2">
                    <i className="ri-file-word-line text-blue-600 text-xl"></i>
                    <span className="text-gray-700">{convertedFile}</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-center space-x-4">
                <button
                  onClick={downloadWord}
                  className="bg-green-600 text-white px-8 py-4 rounded-lg hover:bg-green-700 transition-colors font-semibold text-lg whitespace-nowrap cursor-pointer"
                >
                  <i className="ri-download-line mr-2"></i>
                  Download Word
                </button>
                <button
                  onClick={resetTool}
                  className="bg-red-600 text-white px-8 py-4 rounded-lg hover:bg-red-700 transition-colors font-semibold text-lg whitespace-nowrap cursor-pointer"
                >
                  Convert Another File
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-edit-line text-xl text-red-600"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Fully Editable</h3>
            <p className="text-gray-600">Convert PDFs to fully editable Word documents with preserved formatting and layout.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-shield-check-line text-xl text-blue-600"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Secure Process</h3>
            <p className="text-gray-600">Your files are processed securely and deleted automatically after conversion.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-time-line text-xl text-green-600"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Quick Results</h3>
            <p className="text-gray-600">Get your converted Word document in seconds with our fast processing engine.</p>
          </div>
        </div>

        {/* Related Tools */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Related Tools</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link href="/tools/word-to-pdf" className="p-4 border border-gray-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <i className="ri-file-word-line text-blue-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Word to PDF</div>
                  <div className="text-sm text-gray-600">Convert Word to PDF</div>
                </div>
              </div>
            </Link>
            <Link href="/tools/image-compressor" className="p-4 border border-gray-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <i className="ri-image-line text-green-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Image Compressor</div>
                  <div className="text-sm text-gray-600">Optimize image sizes</div>
                </div>
              </div>
            </Link>
            <Link href="/tools/qr-generator" className="p-4 border border-gray-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <i className="ri-qr-code-line text-purple-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">QR Generator</div>
                  <div className="text-sm text-gray-600">Create QR codes</div>
                </div>
              </div>
            </Link>
          </div>
        </div>

        {/* Article Content */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <article className="prose max-w-none">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Ultimate Guide to PDF to Word Conversion</h2>
            
            <p className="text-lg text-gray-700 mb-6">
              Converting PDF files to editable Word documents is essential for document editing, content extraction, and collaborative work. Our advanced PDF to Word converter maintains formatting while making your documents fully editable.
            </p>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Why Convert PDF to Word?</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-blue-50 p-6 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-3">Document Editing</h4>
                <ul className="space-y-2 text-blue-800 text-sm">
                  <li>• Make text changes and corrections</li>
                  <li>• Add or remove content easily</li>
                  <li>• Modify formatting and layout</li>
                  <li>• Insert images and tables</li>
                </ul>
              </div>
              <div className="bg-green-50 p-6 rounded-lg">
                <h4 className="font-semibold text-green-900 mb-3">Content Reuse</h4>
                <ul className="space-y-2 text-green-800 text-sm">
                  <li>• Extract text for other documents</li>
                  <li>• Repurpose existing content</li>
                  <li>• Enable collaboration features</li>
                  <li>• Version control and tracking</li>
                </ul>
              </div>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Conversion Process</h3>
            <div className="space-y-4 mb-8">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center font-semibold text-sm">1</div>
                <div>
                  <h4 className="font-semibold text-gray-900">Upload PDF File</h4>
                  <p className="text-gray-600">Select your PDF file using the upload button or drag and drop it into the conversion area.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center font-semibold text-sm">2</div>
                <div>
                  <h4 className="font-semibold text-gray-900">Process Conversion</h4>
                  <p className="text-gray-600">Our advanced OCR technology analyzes and converts your PDF content while preserving formatting.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center font-semibold text-sm">3</div>
                <div>
                  <h4 className="font-semibold text-gray-900">Download Word Document</h4>
                  <p className="text-gray-600">Get your fully editable Word document ready for modification and collaboration.</p>
                </div>
              </div>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Conversion Quality Tips</h3>
            <div className="bg-gray-50 p-6 rounded-lg mb-6">
              <ul className="space-y-3">
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Use high-quality PDF files with clear, readable text</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Avoid heavily formatted or complex layout PDFs</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Text-based PDFs convert better than image-based ones</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Review the converted document for any formatting adjustments</span>
                </li>
              </ul>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Common Use Cases</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-blue-50 p-6 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">Legal Documents</h4>
                <p className="text-blue-800 text-sm">Convert contracts and legal papers for editing and collaboration</p>
              </div>
              <div className="bg-green-50 p-6 rounded-lg">
                <h4 className="font-semibold text-green-900 mb-2">Academic Papers</h4>
                <p className="text-green-800 text-sm">Edit research papers and academic documents</p>
              </div>
              <div className="bg-purple-50 p-6 rounded-lg">
                <h4 className="font-semibold text-purple-900 mb-2">Business Reports</h4>
                <p className="text-purple-800 text-sm">Modify business reports and presentations</p>
              </div>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Frequently Asked Questions</h3>
            <div className="space-y-6">
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">Is the PDF to Word conversion free?</h4>
                <p className="text-gray-700">Yes, our PDF to Word converter is completely free with unlimited conversions and no registration required.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">How accurate is the conversion?</h4>
                <p className="text-gray-700">Our OCR technology provides high accuracy for text-based PDFs. Complex layouts may require minor formatting adjustments.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">Can I convert password-protected PDFs?</h4>
                <p className="text-gray-700">Currently, we support conversion of non-password-protected PDFs. Please remove password protection before uploading.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">What happens to images in the PDF?</h4>
                <p className="text-gray-700">Images are preserved and embedded in the converted Word document, maintaining their original quality and position.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">Is my data secure during conversion?</h4>
                <p className="text-gray-700">Yes, all files are processed securely with SSL encryption and automatically deleted after conversion completion.</p>
              </div>
            </div>
          </article>
        </div>
      </div>
    </div>
  );
}
