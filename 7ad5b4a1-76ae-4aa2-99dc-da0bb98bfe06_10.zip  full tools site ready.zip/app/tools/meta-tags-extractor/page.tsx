'use client';

import { useState } from 'react';
import Link from 'next/link';

interface MetaTags {
  title: string;
  description: string;
  keywords: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  ogUrl: string;
  twitterTitle: string;
  twitterDescription: string;
  twitterImage: string;
  canonical: string;
  robots: string;
  viewport: string;
  charset: string;
  author: string;
  generator: string;
  language: string;
}

export default function MetaTagsExtractorPage() {
  const [url, setUrl] = useState('');
  const [isExtracting, setIsExtracting] = useState(false);
  const [metaTags, setMetaTags] = useState<MetaTags | null>(null);
  const [error, setError] = useState('');

  const extractMetaTags = async () => {
    if (!url.trim()) {
      setError('Please enter a valid URL');
      return;
    }

    try {
      const urlObj = new URL(url.includes('://') ? url : `https://${url}`);
      
      setIsExtracting(true);
      setError('');
      setMetaTags(null);

      // Simulate API call
      setTimeout(() => {
        const mockMetaTags: MetaTags = {
          title: 'Professional Web Development Services | Your Company Name',
          description: 'Expert web development, design, and digital marketing services. Build responsive websites, mobile apps, and grow your online presence with our experienced team.',
          keywords: 'web development, website design, digital marketing, SEO, mobile apps, responsive design',
          ogTitle: 'Professional Web Development Services',
          ogDescription: 'Transform your business with our expert web development and digital marketing services. Get started today!',
          ogImage: 'https://example.com/images/og-image.jpg',
          ogUrl: urlObj.href,
          twitterTitle: 'Professional Web Development Services',
          twitterDescription: 'Expert web development and digital marketing services for your business growth.',
          twitterImage: 'https://example.com/images/twitter-image.jpg',
          canonical: urlObj.href,
          robots: 'index, follow',
          viewport: 'width=device-width, initial-scale=1.0',
          charset: 'UTF-8',
          author: 'Your Company Name',
          generator: 'WordPress 6.3',
          language: 'en-US'
        };

        setMetaTags(mockMetaTags);
        setIsExtracting(false);
      }, 2000);

    } catch (err) {
      setError('Please enter a valid URL (e.g., example.com or https://example.com)');
      setIsExtracting(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const exportAsHTML = () => {
    if (!metaTags) return;
    
    const htmlContent = `<!-- Basic Meta Tags -->
<meta charset="${metaTags.charset}">
<meta name="viewport" content="${metaTags.viewport}">
<title>${metaTags.title}</title>
<meta name="description" content="${metaTags.description}">
<meta name="keywords" content="${metaTags.keywords}">
<meta name="author" content="${metaTags.author}">
<meta name="robots" content="${metaTags.robots}">
<link rel="canonical" href="${metaTags.canonical}">

<!-- Open Graph Meta Tags -->
<meta property="og:title" content="${metaTags.ogTitle}">
<meta property="og:description" content="${metaTags.ogDescription}">
<meta property="og:image" content="${metaTags.ogImage}">
<meta property="og:url" content="${metaTags.ogUrl}">
<meta property="og:type" content="website">

<!-- Twitter Card Meta Tags -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${metaTags.twitterTitle}">
<meta name="twitter:description" content="${metaTags.twitterDescription}">
<meta name="twitter:image" content="${metaTags.twitterImage}">`;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'meta-tags.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Link href="/" className="hover:text-blue-600 cursor-pointer">Home</Link>
            <i className="ri-arrow-right-s-line"></i>
            <Link href="/tools" className="hover:text-blue-600 cursor-pointer">Tools</Link>
            <i className="ri-arrow-right-s-line"></i>
            <span className="text-gray-900">Meta Tags Extractor</span>
          </div>
        </nav>

        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-indigo-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="ri-code-line text-2xl text-indigo-600"></i>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Meta Tags Extractor
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Extract and analyze all meta tags from any website including Open Graph, Twitter Cards, and SEO meta data.
          </p>
        </div>

        {/* Tool Interface */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="max-w-2xl mx-auto">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Enter Website URL
            </label>
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com"
                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
                onKeyPress={(e) => e.key === 'Enter' && extractMetaTags()}
              />
              <button
                onClick={extractMetaTags}
                disabled={isExtracting}
                className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors disabled:bg-indigo-400 disabled:cursor-not-allowed font-semibold whitespace-nowrap cursor-pointer"
              >
                {isExtracting ? 'Extracting...' : 'Extract Meta Tags'}
              </button>
            </div>
            {error && (
              <div className="mt-3 text-red-600 text-sm">{error}</div>
            )}
          </div>
        </div>

        {/* Loading State */}
        {isExtracting && (
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8 text-center">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <div className="animate-spin w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full"></div>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Extracting Meta Tags</h3>
            <p className="text-gray-600">Please wait while we analyze the website...</p>
          </div>
        )}

        {/* Results */}
        {metaTags && (
          <div className="space-y-8">
            {/* Export Options */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                <h2 className="text-2xl font-bold text-gray-900">Extracted Meta Tags</h2>
                <div className="flex gap-3">
                  <button
                    onClick={exportAsHTML}
                    className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors font-medium whitespace-nowrap cursor-pointer"
                  >
                    <i className="ri-download-line mr-2"></i>
                    Export HTML
                  </button>
                  <button
                    onClick={() => copyToClipboard(JSON.stringify(metaTags, null, 2))}
                    className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors font-medium whitespace-nowrap cursor-pointer"
                  >
                    <i className="ri-file-copy-line mr-2"></i>
                    Copy JSON
                  </button>
                </div>
              </div>
            </div>

            {/* Basic Meta Tags */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                  <i className="ri-file-text-line text-blue-600"></i>
                </div>
                Basic Meta Tags
              </h3>
              
              <div className="space-y-4">
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <label className="text-sm font-medium text-gray-700">Title</label>
                    <button
                      onClick={() => copyToClipboard(metaTags.title)}
                      className="text-indigo-600 hover:text-indigo-700 cursor-pointer"
                    >
                      <i className="ri-file-copy-line"></i>
                    </button>
                  </div>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded">{metaTags.title}</p>
                  <div className="text-xs text-gray-500 mt-2">Length: {metaTags.title.length} characters</div>
                </div>

                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <label className="text-sm font-medium text-gray-700">Description</label>
                    <button
                      onClick={() => copyToClipboard(metaTags.description)}
                      className="text-indigo-600 hover:text-indigo-700 cursor-pointer"
                    >
                      <i className="ri-file-copy-line"></i>
                    </button>
                  </div>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded">{metaTags.description}</p>
                  <div className="text-xs text-gray-500 mt-2">Length: {metaTags.description.length} characters</div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="border border-gray-200 rounded-lg p-4">
                    <label className="text-sm font-medium text-gray-700">Keywords</label>
                    <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2">{metaTags.keywords}</p>
                  </div>
                  <div className="border border-gray-200 rounded-lg p-4">
                    <label className="text-sm font-medium text-gray-700">Author</label>
                    <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2">{metaTags.author}</p>
                  </div>
                  <div className="border border-gray-200 rounded-lg p-4">
                    <label className="text-sm font-medium text-gray-700">Robots</label>
                    <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2">{metaTags.robots}</p>
                  </div>
                  <div className="border border-gray-200 rounded-lg p-4">
                    <label className="text-sm font-medium text-gray-700">Canonical URL</label>
                    <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2 break-all">{metaTags.canonical}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Open Graph Meta Tags */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                  <i className="ri-share-line text-green-600"></i>
                </div>
                Open Graph Meta Tags
              </h3>
              
              <div className="space-y-4">
                <div className="border border-gray-200 rounded-lg p-4">
                  <label className="text-sm font-medium text-gray-700">OG Title</label>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2">{metaTags.ogTitle}</p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4">
                  <label className="text-sm font-medium text-gray-700">OG Description</label>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2">{metaTags.ogDescription}</p>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="border border-gray-200 rounded-lg p-4">
                    <label className="text-sm font-medium text-gray-700">OG Image</label>
                    <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2 break-all">{metaTags.ogImage}</p>
                  </div>
                  <div className="border border-gray-200 rounded-lg p-4">
                    <label className="text-sm font-medium text-gray-700">OG URL</label>
                    <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2 break-all">{metaTags.ogUrl}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Twitter Card Meta Tags */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                  <i className="ri-twitter-line text-blue-600"></i>
                </div>
                Twitter Card Meta Tags
              </h3>
              
              <div className="space-y-4">
                <div className="border border-gray-200 rounded-lg p-4">
                  <label className="text-sm font-medium text-gray-700">Twitter Title</label>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2">{metaTags.twitterTitle}</p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4">
                  <label className="text-sm font-medium text-gray-700">Twitter Description</label>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2">{metaTags.twitterDescription}</p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4">
                  <label className="text-sm font-medium text-gray-700">Twitter Image</label>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2 break-all">{metaTags.twitterImage}</p>
                </div>
              </div>
            </div>

            {/* Technical Meta Tags */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                  <i className="ri-settings-line text-purple-600"></i>
                </div>
                Technical Meta Tags
              </h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="border border-gray-200 rounded-lg p-4">
                  <label className="text-sm font-medium text-gray-700">Charset</label>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2">{metaTags.charset}</p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4">
                  <label className="text-sm font-medium text-gray-700">Viewport</label>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2">{metaTags.viewport}</p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4">
                  <label className="text-sm font-medium text-gray-700">Generator</label>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2">{metaTags.generator}</p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4">
                  <label className="text-sm font-medium text-gray-700">Language</label>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded mt-2">{metaTags.language}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="text-center p-6">
            <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-code-line text-xl text-indigo-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Complete Analysis</h3>
            <p className="text-sm text-gray-600">
              Extract all meta tags including Open Graph and Twitter Cards
            </p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-download-line text-xl text-green-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Export Options</h3>
            <p className="text-sm text-gray-600">
              Download as HTML or copy as JSON format
            </p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-shield-check-line text-xl text-blue-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">SEO Analysis</h3>
            <p className="text-sm text-gray-600">
              Check title and description length for SEO optimization
            </p>
          </div>
        </div>

        {/* Article Content */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Understanding Meta Tags for SEO
          </h2>

          <div className="prose prose-lg max-w-none text-gray-700">
            <p className="mb-4">
              Meta tags are HTML elements that provide metadata about a web page. They don't appear on the page itself but are crucial for search engines and social media platforms to understand your content.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3 mt-8">
              Essential Meta Tags
            </h3>
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div className="border border-gray-200 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-2">Title Tag</h4>
                <p className="text-sm text-gray-600 mb-2">
                  The most important meta tag for SEO. Should be 50-60 characters.
                </p>
                <code className="text-xs bg-gray-100 p-2 rounded block">
                  &lt;title&gt;Your Page Title&lt;/title&gt;
                </code>
              </div>
              <div className="border border-gray-200 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-2">Meta Description</h4>
                <p className="text-sm text-gray-600 mb-2">
                  Appears in search results. Should be 150-160 characters.
                </p>
                <code className="text-xs bg-gray-100 p-2 rounded block">
                  &lt;meta name="description" content="..."&gt;
                </code>
              </div>
            </div>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Open Graph Tags
            </h3>
            <p className="mb-4">
              Open Graph meta tags control how your content appears when shared on social media platforms like Facebook, LinkedIn, and others.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Twitter Card Tags
            </h3>
            <p className="mb-4">
              Twitter Card meta tags control how your content appears when shared on Twitter, providing a rich media experience.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Best Practices
            </h3>
            <ul className="list-disc pl-6 mb-6">
              <li className="mb-2">Keep title tags under 60 characters</li>
              <li className="mb-2">Write compelling meta descriptions under 160 characters</li>
              <li className="mb-2">Use unique meta tags for each page</li>
              <li className="mb-2">Include target keywords naturally</li>
              <li className="mb-2">Set up Open Graph and Twitter Cards for social sharing</li>
              <li className="mb-2">Use canonical URLs to avoid duplicate content</li>
            </ul>
          </div>
        </div>

        {/* FAQ */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h2>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                What are meta tags and why are they important?
              </h3>
              <p className="text-gray-700">
                Meta tags are HTML elements that provide information about a web page to search engines and other services. They're crucial for SEO, social media sharing, and user experience.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                How often should I update my meta tags?
              </h3>
              <p className="text-gray-700">
                Update meta tags when you change your content, target new keywords, or want to improve click-through rates from search results.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Can I use the same meta tags for all pages?
              </h3>
              <p className="text-gray-700">
                No, each page should have unique meta tags that accurately describe its specific content. Duplicate meta tags can hurt your SEO performance.
              </p>
            </div>
          </div>
        </div>

        {/* Related Tools */}
        <div className="bg-indigo-50 rounded-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Related SEO Tools
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/tools/domain-authority-checker" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-global-line text-purple-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">DA Checker</div>
            </Link>

            <Link href="/tools/backlink-checker" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-links-line text-blue-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">Backlinks</div>
            </Link>

            <Link href="/tools/plagiarism-checker" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-teal-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-shield-check-line text-teal-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">Plagiarism</div>
            </Link>

            <Link href="/tools" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-apps-line text-gray-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">All Tools</div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}