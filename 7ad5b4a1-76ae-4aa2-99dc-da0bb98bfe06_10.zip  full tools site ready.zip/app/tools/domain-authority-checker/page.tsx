'use client';

import { useState } from 'react';
import Link from 'next/link';

interface DomainStats {
  domain: string;
  domainAuthority: number;
  pageAuthority: number;
  spamScore: number;
  linkingDomains: number;
  totalBacklinks: number;
  organicKeywords: number;
  organicTraffic: number;
}

export default function DomainAuthorityPage() {
  const [url, setUrl] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<DomainStats | null>(null);
  const [error, setError] = useState('');

  const analyzeURL = async () => {
    if (!url.trim()) {
      setError('Please enter a valid URL');
      return;
    }

    try {
      const urlObj = new URL(url.includes('://') ? url : `https://${url}`);
      const domain = urlObj.hostname.replace('www.', '');
      
      setIsAnalyzing(true);
      setError('');
      setResults(null);

      // Simulate API call
      setTimeout(() => {
        const mockResults: DomainStats = {
          domain: domain,
          domainAuthority: Math.floor(Math.random() * 40) + 30,
          pageAuthority: Math.floor(Math.random() * 35) + 25,
          spamScore: Math.floor(Math.random() * 20) + 1,
          linkingDomains: Math.floor(Math.random() * 5000) + 500,
          totalBacklinks: Math.floor(Math.random() * 50000) + 5000,
          organicKeywords: Math.floor(Math.random() * 10000) + 1000,
          organicTraffic: Math.floor(Math.random() * 100000) + 10000,
        };

        setResults(mockResults);
        setIsAnalyzing(false);
      }, 2500);

    } catch (err) {
      setError('Please enter a valid URL (e.g., example.com or https://example.com)');
      setIsAnalyzing(false);
    }
  };

  const getDomainRating = (da: number) => {
    if (da >= 70) return { text: 'Excellent', color: 'text-green-600', bg: 'bg-green-100' };
    if (da >= 50) return { text: 'Good', color: 'text-blue-600', bg: 'bg-blue-100' };
    if (da >= 30) return { text: 'Average', color: 'text-yellow-600', bg: 'bg-yellow-100' };
    return { text: 'Poor', color: 'text-red-600', bg: 'bg-red-100' };
  };

  const getSpamRating = (score: number) => {
    if (score <= 5) return { text: 'Low Risk', color: 'text-green-600', bg: 'bg-green-100' };
    if (score <= 15) return { text: 'Medium Risk', color: 'text-yellow-600', bg: 'bg-yellow-100' };
    return { text: 'High Risk', color: 'text-red-600', bg: 'bg-red-100' };
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="ri-global-line text-3xl text-purple-600"></i>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Domain Authority Checker
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Check Domain Authority (DA), Page Authority (PA), and other important SEO metrics for any website instantly.
          </p>
        </div>

        {/* Search Tool */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="max-w-2xl mx-auto">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Enter Website URL
            </label>
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="example.com or https://example.com"
                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-200"
                onKeyPress={(e) => e.key === 'Enter' && analyzeURL()}
              />
              <button
                onClick={analyzeURL}
                disabled={isAnalyzing}
                className="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors disabled:bg-purple-400 disabled:cursor-not-allowed font-semibold whitespace-nowrap cursor-pointer"
              >
                {isAnalyzing ? 'Analyzing...' : 'Check DA/PA'}
              </button>
            </div>
            {error && (
              <div className="mt-3 text-red-600 text-sm">
                {error}
              </div>
            )}
          </div>
        </div>

        {/* Loading State */}
        {isAnalyzing && (
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8 text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <div className="animate-spin w-8 h-8 border-2 border-purple-600 border-t-transparent rounded-full"></div>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Analyzing Domain Authority</h3>
            <p className="text-gray-600">Please wait while we fetch SEO metrics for your domain...</p>
          </div>
        )}

        {/* Results */}
        {results && (
          <div className="space-y-8">
            {/* Main Metrics */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Domain Analysis Results</h3>
                  <p className="text-gray-600">{results.domain}</p>
                </div>
                <div className="text-right">
                  <div className={`inline-flex px-3 py-1 rounded-full text-sm font-medium ${getDomainRating(results.domainAuthority).bg} ${getDomainRating(results.domainAuthority).color}`}>
                    {getDomainRating(results.domainAuthority).text}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="text-center p-6 bg-blue-50 rounded-lg">
                  <div className="text-3xl font-bold text-blue-600 mb-2">{results.domainAuthority}</div>
                  <div className="text-sm text-blue-800 font-medium">Domain Authority</div>
                  <div className="text-xs text-blue-600 mt-1">Scale: 1-100</div>
                </div>
                
                <div className="text-center p-6 bg-green-50 rounded-lg">
                  <div className="text-3xl font-bold text-green-600 mb-2">{results.pageAuthority}</div>
                  <div className="text-sm text-green-800 font-medium">Page Authority</div>
                  <div className="text-xs text-green-600 mt-1">Scale: 1-100</div>
                </div>

                <div className="text-center p-6 bg-red-50 rounded-lg">
                  <div className="text-3xl font-bold text-red-600 mb-2">{results.spamScore}%</div>
                  <div className="text-sm text-red-800 font-medium">Spam Score</div>
                  <div className={`text-xs mt-1 ${getSpamRating(results.spamScore).color}`}>
                    {getSpamRating(results.spamScore).text}
                  </div>
                </div>

                <div className="text-center p-6 bg-purple-50 rounded-lg">
                  <div className="text-3xl font-bold text-purple-600 mb-2">{results.linkingDomains.toLocaleString()}</div>
                  <div className="text-sm text-purple-800 font-medium">Linking Domains</div>
                  <div className="text-xs text-purple-600 mt-1">Unique domains</div>
                </div>
              </div>
            </div>

            {/* Additional Metrics */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Additional SEO Metrics</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <i className="ri-links-line text-blue-600"></i>
                    </div>
                    <div className="text-2xl font-bold text-gray-900">{results.totalBacklinks.toLocaleString()}</div>
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-1">Total Backlinks</h4>
                  <p className="text-sm text-gray-600">All incoming links to this domain</p>
                </div>

                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <i className="ri-search-line text-green-600"></i>
                    </div>
                    <div className="text-2xl font-bold text-gray-900">{results.organicKeywords.toLocaleString()}</div>
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-1">Organic Keywords</h4>
                  <p className="text-sm text-gray-600">Keywords ranking in top 100</p>
                </div>

                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                      <i className="ri-line-chart-line text-orange-600"></i>
                    </div>
                    <div className="text-2xl font-bold text-gray-900">{results.organicTraffic.toLocaleString()}</div>
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-1">Organic Traffic</h4>
                  <p className="text-sm text-gray-600">Estimated monthly visits</p>
                </div>
              </div>
            </div>

            {/* Improvement Suggestions */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">SEO Improvement Suggestions</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900 flex items-center">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-2">
                      <i className="ri-arrow-up-line text-blue-600 text-sm"></i>
                    </div>
                    Increase Domain Authority
                  </h4>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li>• Build high-quality backlinks from authoritative sites</li>
                    <li>• Create valuable, shareable content</li>
                    <li>• Improve internal link structure</li>
                    <li>• Guest posting on relevant domains</li>
                  </ul>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900 flex items-center">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mr-2">
                      <i className="ri-shield-check-line text-green-600 text-sm"></i>
                    </div>
                    Reduce Spam Score
                  </h4>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li>• Audit and disavow toxic backlinks</li>
                    <li>• Avoid link schemes and paid links</li>
                    <li>• Focus on earning natural, relevant links</li>
                    <li>• Monitor backlink profile regularly</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Related Tools */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Related SEO Tools</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link href="/tools/backlink-checker" className="p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <i className="ri-links-line text-blue-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Backlink Checker</div>
                  <div className="text-sm text-gray-600">Analyze backlinks</div>
                </div>
              </div>
            </Link>
            <Link href="/tools/meta-tags-extractor" className="p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <i className="ri-code-line text-indigo-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Meta Tags Extractor</div>
                  <div className="text-sm text-gray-600">Extract meta data</div>
                </div>
              </div>
            </Link>
            <Link href="/tools/plagiarism-checker" className="p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                  <i className="ri-shield-check-line text-teal-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Plagiarism Checker</div>
                  <div className="text-sm text-gray-600">Check content originality</div>
                </div>
              </div>
            </Link>
          </div>
        </div>

        {/* Article Content */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <article className="prose max-w-none">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Understanding Domain Authority and SEO Metrics</h2>
            
            <p className="text-lg text-gray-700 mb-6">
              Domain Authority (DA) is a search engine ranking score developed by Moz that predicts how well a website will rank on search engine result pages. Understanding and monitoring your DA is crucial for SEO success.
            </p>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">What is Domain Authority?</h3>
            <div className="bg-blue-50 p-6 rounded-lg mb-6">
              <p className="text-blue-900">
                Domain Authority is calculated using multiple factors including linking root domains, number of total links, MozRank, MozTrust, and more. Scores range from 1 to 100, with higher scores corresponding to greater ability to rank.
              </p>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Key SEO Metrics Explained</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <div className="w-6 h-6 bg-blue-100 rounded-lg flex items-center justify-center mr-2">
                    <i className="ri-global-line text-blue-600 text-sm"></i>
                  </div>
                  Domain Authority (DA)
                </h4>
                <p className="text-gray-700 text-sm">Predicts ranking ability of entire domain. Higher DA indicates stronger potential to rank well in search results.</p>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <div className="w-6 h-6 bg-green-100 rounded-lg flex items-center justify-center mr-2">
                    <i className="ri-file-line text-green-600 text-sm"></i>
                  </div>
                  Page Authority (PA)
                </h4>
                <p className="text-gray-700 text-sm">Similar to DA but predicts ranking potential of individual pages rather than entire domains.</p>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <div className="w-6 h-6 bg-red-100 rounded-lg flex items-center justify-center mr-2">
                    <i className="ri-shield-line text-red-600 text-sm"></i>
                  </div>
                  Spam Score
                </h4>
                <p className="text-gray-700 text-sm">Percentage representing likelihood of a site being penalized or banned by Google. Lower is better.</p>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <div className="w-6 h-6 bg-purple-100 rounded-lg flex items-center justify-center mr-2">
                    <i className="ri-links-line text-purple-600 text-sm"></i>
                  </div>
                  Linking Domains
                </h4>
                <p className="text-gray-700 text-sm">Number of unique domains that link to your website. Quality and relevance matter more than quantity.</p>
              </div>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">How to Improve Your Domain Authority</h3>
            <div className="space-y-6 mb-8">
              <div className="border-l-4 border-blue-500 pl-6">
                <h4 className="font-semibold text-gray-900 mb-2">1. Create High-Quality Content</h4>
                <p className="text-gray-700">Produce valuable, original content that naturally attracts links and social shares. Content quality is the foundation of SEO success.</p>
              </div>
              
              <div className="border-l-4 border-green-500 pl-6">
                <h4 className="font-semibold text-gray-900 mb-2">2. Build Quality Backlinks</h4>
                <p className="text-gray-700">Focus on earning links from authoritative, relevant websites in your industry. Avoid low-quality or spammy link building tactics.</p>
              </div>
              
              <div className="border-l-4 border-purple-500 pl-6">
                <h4 className="font-semibold text-gray-900 mb-2">3. Optimize Internal Linking</h4>
                <p className="text-gray-700">Create a strong internal link structure that helps search engines understand your site hierarchy and distributes link equity.</p>
              </div>
              
              <div className="border-l-4 border-orange-500 pl-6">
                <h4 className="font-semibold text-gray-900 mb-2">4. Improve Technical SEO</h4>
                <p className="text-gray-700">Ensure your website is fast, mobile-friendly, and technically sound. Fix crawl errors and optimize site architecture.</p>
              </div>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Domain Authority Benchmarks</h3>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-300 mb-8">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border border-gray-300 px-4 py-2 text-left">DA Range</th>
                    <th className="border border-gray-300 px-4 py-2 text-left">Rating</th>
                    <th className="border border-gray-300 px-4 py-2 text-left">Description</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-gray-300 px-4 py-2">70-100</td>
                    <td className="border border-gray-300 px-4 py-2"><span className="bg-green-100 text-green-800 px-2 py-1 rounded text-sm">Excellent</span></td>
                    <td className="border border-gray-300 px-4 py-2">Major brands, news sites, educational institutions</td>
                  </tr>
                  <tr>
                    <td className="border border-gray-300 px-4 py-2">50-69</td>
                    <td className="border border-gray-300 px-4 py-2"><span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">Good</span></td>
                    <td className="border border-gray-300 px-4 py-2">Established businesses, popular blogs</td>
                  </tr>
                  <tr>
                    <td className="border border-gray-300 px-4 py-2">30-49</td>
                    <td className="border border-gray-300 px-4 py-2"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-sm">Average</span></td>
                    <td className="border border-gray-300 px-4 py-2">Small to medium businesses, niche sites</td>
                  </tr>
                  <tr>
                    <td className="border border-gray-300 px-4 py-2">1-29</td>
                    <td className="border border-gray-300 px-4 py-2"><span className="bg-red-100 text-red-800 px-2 py-1 rounded text-sm">Poor</span></td>
                    <td className="border border-gray-300 px-4 py-2">New websites, low authority domains</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Frequently Asked Questions</h3>
            <div className="space-y-6">
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">How often should I check my Domain Authority?</h4>
                <p className="text-gray-700">Check your DA monthly or quarterly. Daily checking is unnecessary as DA changes gradually over time with consistent SEO efforts.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">Can Domain Authority decrease?</h4>
                <p className="text-gray-700">Yes, DA can decrease if competitors improve their metrics or if you lose high-quality backlinks. It's relative to other websites.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">Is Domain Authority a Google ranking factor?</h4>
                <p className="text-gray-700">No, DA is a Moz metric, not a Google ranking factor. However, factors that improve DA often correlate with better Google rankings.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">What's a good Domain Authority score?</h4>
                <p className="text-gray-700">It depends on your industry and competition. Focus on improving relative to competitors rather than achieving a specific number.</p>
              </div>
            </div>
          </article>
        </div>
      </div>
    </div>
  );
}