'use client';

import { useState, useRef } from 'react';
import Link from 'next/link';

export default function ImageCompressorPage() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [compressedFile, setCompressedFile] = useState<string | null>(null);
  const [isCompressing, setIsCompressing] = useState(false);
  const [compressionQuality, setCompressionQuality] = useState(80);
  const [originalSize, setOriginalSize] = useState(0);
  const [compressedSize, setCompressedSize] = useState(0);
  const [dragActive, setDragActive] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/')) {
        setSelectedFile(file);
        setOriginalSize(file.size);
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setOriginalSize(file.size);
    }
  };

  const compressImage = async () => {
    if (!selectedFile || !canvasRef.current) return;
    
    setIsCompressing(true);
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.onload = () => {
      // Calculate new dimensions while maintaining aspect ratio
      let { width, height } = img;
      const maxWidth = 1920;
      const maxHeight = 1080;
      
      if (width > maxWidth || height > maxHeight) {
        const ratio = Math.min(maxWidth / width, maxHeight / height);
        width *= ratio;
        height *= ratio;
      }
      
      canvas.width = width;
      canvas.height = height;
      
      // Draw and compress
      ctx?.drawImage(img, 0, 0, width, height);
      
      canvas.toBlob(
        (blob) => {
          if (blob) {
            const compressedUrl = URL.createObjectURL(blob);
            setCompressedFile(compressedUrl);
            setCompressedSize(blob.size);
          }
          setIsCompressing(false);
        },
        'image/jpeg',
        compressionQuality / 100
      );
    };
    
    img.src = URL.createObjectURL(selectedFile);
  };

  const downloadCompressed = () => {
    if (!compressedFile) return;
    
    const link = document.createElement('a');
    link.href = compressedFile;
    link.download = `compressed_${selectedFile?.name || 'image.jpg'}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const resetTool = () => {
    setSelectedFile(null);
    setCompressedFile(null);
    setOriginalSize(0);
    setCompressedSize(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const compressionRatio = originalSize > 0 ? ((originalSize - compressedSize) / originalSize * 100).toFixed(1) : 0;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Link href="/" className="hover:text-blue-600">Home</Link>
            <i className="ri-arrow-right-s-line"></i>
            <Link href="/tools" className="hover:text-blue-600">Tools</Link>
            <i className="ri-arrow-right-s-line"></i>
            <span className="text-gray-900">Image Compressor</span>
          </div>
        </nav>

        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="ri-image-line text-2xl text-green-600"></i>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Image Compressor
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Reduce image file size without losing quality. Optimize images for web, email, and storage.
          </p>
        </div>

        {/* Tool Interface */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          {!selectedFile ? (
            <div
              className={`border-2 border-dashed rounded-xl p-12 text-center transition-colors ${
                dragActive ? 'border-green-500 bg-green-50' : 'border-gray-300 hover:border-green-400'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-upload-cloud-line text-2xl text-green-600"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Drop your image here
              </h3>
              <p className="text-gray-600 mb-4">
                Supports JPG, PNG, WebP formats up to 10MB
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors cursor-pointer inline-block whitespace-nowrap"
              >
                Select Image
              </label>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Image Preview and Controls */}
              <div className="grid lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Original Image</h3>
                  <div className="border rounded-lg p-4">
                    <img
                      src={URL.createObjectURL(selectedFile)}
                      alt="Original"
                      className="w-full h-48 object-cover object-top rounded"
                    />
                    <div className="mt-3 text-sm text-gray-600">
                      <p><strong>File:</strong> {selectedFile.name}</p>
                      <p><strong>Size:</strong> {formatFileSize(originalSize)}</p>
                      <p><strong>Type:</strong> {selectedFile.type}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    {compressedFile ? 'Compressed Image' : 'Preview'}
                  </h3>
                  <div className="border rounded-lg p-4">
                    {compressedFile ? (
                      <>
                        <img
                          src={compressedFile}
                          alt="Compressed"
                          className="w-full h-48 object-cover object-top rounded"
                        />
                        <div className="mt-3 text-sm text-gray-600">
                          <p><strong>Size:</strong> {formatFileSize(compressedSize)}</p>
                          <p><strong>Reduced by:</strong> {compressionRatio}%</p>
                          <p className="text-green-600"><strong>Quality:</strong> {compressionQuality}%</p>
                        </div>
                      </>
                    ) : (
                      <div className="w-full h-48 bg-gray-100 rounded flex items-center justify-center">
                        <div className="text-center text-gray-500">
                          <i className="ri-image-line text-3xl mb-2"></i>
                          <p>Compressed image will appear here</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Compression Settings */}
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Compression Settings</h3>
                
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Quality: {compressionQuality}%
                  </label>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    step="5"
                    value={compressionQuality}
                    onChange={(e) => setCompressionQuality(parseInt(e.target.value))}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>Smaller file</span>
                    <span>Better quality</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-4">
                  <button
                    onClick={compressImage}
                    disabled={isCompressing}
                    className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2 whitespace-nowrap"
                  >
                    {isCompressing ? (
                      <>
                        <i className="ri-loader-4-line animate-spin"></i>
                        <span>Compressing...</span>
                      </>
                    ) : (
                      <>
                        <i className="ri-compasses-2-line"></i>
                        <span>Compress Image</span>
                      </>
                    )}
                  </button>

                  {compressedFile && (
                    <button
                      onClick={downloadCompressed}
                      className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center space-x-2 whitespace-nowrap"
                    >
                      <i className="ri-download-line"></i>
                      <span>Download Compressed</span>
                    </button>
                  )}

                  <button
                    onClick={resetTool}
                    className="border border-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-colors font-medium whitespace-nowrap"
                  >
                    Start Over
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Hidden canvas for compression */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="text-center p-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-speed-line text-xl text-green-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Fast Compression</h3>
            <p className="text-sm text-gray-600">Compress images instantly in your browser</p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-image-line text-xl text-blue-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Quality Control</h3>
            <p className="text-sm text-gray-600">Adjust compression level to balance size and quality</p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-shield-check-line text-xl text-purple-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">100% Private</h3>
            <p className="text-sm text-gray-600">Images processed locally, never uploaded to servers</p>
          </div>
        </div>

        {/* Article Content */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Image Compression Guide - Optimize Your Images
          </h2>
          
          <div className="prose prose-lg max-w-none text-gray-700">
            <p className="mb-4">
              Image compression is essential for web optimization, faster loading times, and efficient storage management. Our free image compressor helps you reduce file sizes while maintaining visual quality, making your images perfect for websites, email attachments, and social media.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3 mt-8">Why Compress Images?</h3>
            <ul className="list-disc pl-6 mb-6">
              <li>Faster website loading speeds improve user experience</li>
              <li>Reduced storage space saves server costs</li>
              <li>Better SEO rankings due to improved page speed</li>
              <li>Easier sharing via email and messaging apps</li>
              <li>Lower bandwidth usage for mobile users</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">How Our Image Compressor Works</h3>
            <ol className="list-decimal pl-6 mb-6">
              <li className="mb-2"><strong>Upload:</strong> Select or drag your image file</li>
              <li className="mb-2"><strong>Adjust:</strong> Set compression quality (10-100%)</li>
              <li className="mb-2"><strong>Compress:</strong> Process image with advanced algorithms</li>
              <li className="mb-2"><strong>Download:</strong> Get your optimized image instantly</li>
            </ol>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">Supported Formats</h3>
            <div className="bg-gray-50 rounded-lg p-6 mb-6">
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">JPEG/JPG</h4>
                  <p className="text-sm text-gray-600">Best for photos with many colors</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">PNG</h4>
                  <p className="text-sm text-gray-600">Ideal for graphics with transparency</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">WebP</h4>
                  <p className="text-sm text-gray-600">Modern format with superior compression</p>
                </div>
              </div>
            </div>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">Compression Quality Guidelines</h3>
            <div className="space-y-3 mb-6">
              <div className="flex items-start space-x-3">
                <span className="bg-red-100 text-red-600 px-2 py-1 rounded text-xs font-medium">10-30%</span>
                <div>
                  <p className="font-medium">High Compression</p>
                  <p className="text-sm text-gray-600">Smallest file size, suitable for thumbnails or web icons</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <span className="bg-yellow-100 text-yellow-600 px-2 py-1 rounded text-xs font-medium">40-70%</span>
                <div>
                  <p className="font-medium">Medium Compression</p>
                  <p className="text-sm text-gray-600">Balanced size and quality, good for web galleries</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <span className="bg-green-100 text-green-600 px-2 py-1 rounded text-xs font-medium">80-100%</span>
                <div>
                  <p className="font-medium">Low Compression</p>
                  <p className="text-sm text-gray-600">Best quality, suitable for printing or detailed viewing</p>
                </div>
              </div>
            </div>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">Best Practices for Image Optimization</h3>
            <div className="bg-blue-50 rounded-lg p-6 mb-6">
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start space-x-2">
                  <i className="ri-check-line text-blue-600 mt-0.5"></i>
                  <span>Choose the right format: JPEG for photos, PNG for graphics</span>
                </li>
                <li className="flex items-start space-x-2">
                  <i className="ri-check-line text-blue-600 mt-0.5"></i>
                  <span>Resize images to actual display dimensions before compression</span>
                </li>
                <li className="flex items-start space-x-2">
                  <i className="ri-check-line text-blue-600 mt-0.5"></i>
                  <span>Test different quality settings to find the sweet spot</span>
                </li>
                <li className="flex items-start space-x-2">
                  <i className="ri-check-line text-blue-600 mt-0.5"></i>
                  <span>Keep original files as backups before compression</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Is this image compressor completely free?
              </h3>
              <p className="text-gray-700">
                Yes, our image compression tool is 100% free with no limits on the number of images you can compress.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                What's the maximum file size I can upload?
              </h3>
              <p className="text-gray-700">
                You can compress images up to 10MB in size. For larger files, consider resizing them first.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Are my images stored on your servers?
              </h3>
              <p className="text-gray-700">
                No, all image processing happens locally in your browser. Your images are never uploaded to our servers, ensuring complete privacy.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                What's the difference between lossy and lossless compression?
              </h3>
              <p className="text-gray-700">
                Lossy compression (JPEG) reduces file size by removing some image data, while lossless compression (PNG) maintains all original data with less size reduction.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Can I compress multiple images at once?
              </h3>
              <p className="text-gray-700">
                Currently, you can compress one image at a time. For batch processing, simply repeat the process for each image.
              </p>
            </div>
          </div>
        </div>

        {/* Related Tools */}
        <div className="bg-green-50 rounded-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Related Tools</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/tools/pdf-to-word" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-file-pdf-line text-red-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">PDF to Word</div>
            </Link>

            <Link href="/tools/qr-generator" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-qr-code-line text-purple-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">QR Generator</div>
            </Link>

            <Link href="/tools/text-to-speech" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-volume-up-line text-orange-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">Text to Speech</div>
            </Link>

            <Link href="/tools/backlink-checker" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-links-line text-blue-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">Backlink Checker</div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}