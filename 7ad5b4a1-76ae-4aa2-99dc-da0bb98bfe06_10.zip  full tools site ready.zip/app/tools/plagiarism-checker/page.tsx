'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function PlagiarismCheckerPage() {
  const [text, setText] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const handleCheck = async () => {
    if (!text.trim()) return;

    setIsChecking(true);

    // Simulate checking process
    await new Promise(resolve => setTimeout(resolve, 4000));

    // Mock results data
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const mockResults = {
      originalityScore: Math.floor(Math.random() * 30) + 70, // 70-100% original
      totalWords: text.split(' ').length,
      checkedSentences: sentences.length,
      plagiarizedSentences: Math.floor(sentences.length * 0.1), // 10% plagiarized
      sources: [
        {
          url: 'https://example-article.com/content-writing-tips',
          title: 'Content Writing Best Practices',
          similarity: 15,
          matchedText: sentences[0] || 'Sample matched text from the content.'
        },
        {
          url: 'https://blog-site.org/digital-marketing',
          title: 'Digital Marketing Strategies',
          similarity: 12,
          matchedText: sentences[1] || 'Another example of matched content.'
        },
        {
          url: 'https://research-paper.edu/study',
          title: 'Academic Research on Communication',
          similarity: 8,
          matchedText: sentences[2] || 'Research-related matched text example.'
        }
      ],
      suggestions: [
        'Rewrite detected similar sentences in your own words',
        'Add proper citations for referenced content',
        'Use quotation marks for direct quotes',
        'Expand on ideas with original analysis'
      ]
    };

    setResults(mockResults);
    setIsChecking(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'text/plain') {
      setUploadedFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        setText(content.substring(0, 5000)); // Limit to 5000 characters
      };
      reader.readAsText(file);
    } else {
      alert('Please upload a text (.txt) file only.');
    }
  };

  const resetTool = () => {
    setText('');
    setResults(null);
    setUploadedFile(null);
  };

  const sampleTexts = [
    "Artificial intelligence is revolutionizing the way businesses operate in the modern digital landscape. Companies are increasingly adopting AI-powered solutions to enhance efficiency and customer experience.",
    "Content marketing has become an essential strategy for businesses looking to establish their online presence. Creating valuable and engaging content helps build trust with potential customers.",
    "Search engine optimization requires a comprehensive understanding of keyword research, content quality, and technical website optimization to achieve better rankings in search results.",
    "Social media platforms provide unprecedented opportunities for businesses to connect with their target audience and build meaningful relationships through authentic engagement strategies."
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Link href="/" className="hover:text-blue-600">Home</Link>
            <i className="ri-arrow-right-s-line"></i>
            <Link href="/tools" className="hover:text-blue-600">Tools</Link>
            <i className="ri-arrow-right-s-line"></i>
            <span className="text-gray-900">Plagiarism Checker</span>
          </div>
        </nav>

        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-teal-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="ri-shield-check-line text-2xl text-teal-600"></i>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Plagiarism Checker
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Check content originality and detect duplicate text across billions of web pages and academic sources.
          </p>
        </div>

        {/* Tool Interface */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Input Section */}
            <div className="lg:col-span-2">
              <div className="flex justify-between items-center mb-4">
                <label className="block text-sm font-medium text-gray-700">
                  Enter Text to Check
                </label>
                <div className="flex items-center space-x-4">
                  <input
                    type="file"
                    accept=".txt"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="file-upload"
                  />
                  <label
                    htmlFor="file-upload"
                    className="text-sm text-blue-600 hover:text-blue-700 cursor-pointer whitespace-nowrap"
                  >
                    Upload Text File
                  </label>
                </div>
              </div>

              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste your text here to check for plagiarism..."
                className="w-full h-80 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-200 resize-none"
                maxLength={5000}
              />

              <div className="flex justify-between items-center mt-2">
                <span className="text-sm text-gray-500">{text.length}/5000 characters</span>
                <button
                  onClick={() => setText('')}
                  className="text-sm text-blue-600 hover:text-blue-700 cursor-pointer whitespace-nowrap"
                >
                  Clear Text
                </button>
              </div>

              {uploadedFile && (
                <div className="mt-4 p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <i className="ri-file-text-line text-green-600"></i>
                    <span className="text-sm text-green-700">
                      Uploaded: {uploadedFile.name}
                    </span>
                  </div>
                </div>
              )}

              {/* Sample Texts */}
              <div className="mt-6">
                <p className="text-sm font-medium text-gray-700 mb-3">Try Sample Texts:</p>
                <div className="grid md:grid-cols-2 gap-3">
                  {sampleTexts.map((sample, index) => (
                    <button
                      key={index}
                      onClick={() => setText(sample)}
                      className="text-left text-sm text-gray-600 hover:text-blue-600 p-3 rounded border border-gray-200 hover:border-blue-300 transition-colors cursor-pointer"
                    >
                      {sample.substring(0, 120)}...
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Section */}
            <div className="lg:col-span-1">
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  Check Settings
                </h3>

                <div className="space-y-4 mb-6">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Web Search</span>
                    <i className="ri-check-line text-green-600"></i>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Academic Papers</span>
                    <i className="ri-check-line text-green-600"></i>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Published Articles</span>
                    <i className="ri-check-line text-green-600"></i>
                  </div>
                </div>

                <button
                  onClick={handleCheck}
                  disabled={!text.trim() || isChecking}
                  className="w-full bg-teal-600 text-white py-3 px-6 rounded-lg hover:bg-teal-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2 whitespace-nowrap"
                >
                  {isChecking ? (
                    <>
                      <i className="ri-loader-4-line animate-spin"></i>
                      <span>Checking...</span>
                    </>
                  ) : (
                    <>
                      <i className="ri-search-line"></i>
                      <span>Check Plagiarism</span>
                    </>
                  )}
                </button>

                {results && (
                  <button
                    onClick={resetTool}
                    className="w-full mt-3 border border-gray-300 text-gray-700 py-3 px-6 rounded-lg hover:bg-gray-50 transition-colors font-medium whitespace-nowrap"
                  >
                    Check New Text
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Results */}
        {results && (
          <div className="space-y-8">
            {/* Overview Stats */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-lg p-6 text-center">
                <div
                  className={`w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4 ${
                    results.originalityScore >= 90
                      ? 'bg-green-100'
                      : results.originalityScore >= 70
                      ? 'bg-yellow-100'
                      : 'bg-red-100'
                  }`}
                >
                  <i
                    className={`text-xl ${
                      results.originalityScore >= 90
                        ? 'ri-shield-check-line text-green-600'
                        : results.originalityScore >= 70
                        ? 'ri-error-warning-line text-yellow-600'
                        : 'ri-error-warning-fill text-red-600'
                    }`}
                  ></i>
                </div>
                <h3
                  className={`text-2xl font-bold ${
                    results.originalityScore >= 90
                      ? 'text-green-600'
                      : results.originalityScore >= 70
                      ? 'text-yellow-600'
                      : 'text-red-600'
                  }`}
                >
                  {results.originalityScore}%
                </h3>
                <p className="text-gray-600">Original Content</p>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6 text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <i className="ri-file-text-line text-blue-600 text-xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">
                  {results.totalWords}
                </h3>
                <p className="text-gray-600">Words Checked</p>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6 text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <i className="ri-list-check-line text-purple-600 text-xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">
                  {results.checkedSentences}
                </h3>
                <p className="text-gray-600">Sentences Analyzed</p>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6 text-center">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <i className="ri-links-line text-orange-600 text-xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">
                  {results.sources.length}
                </h3>
                <p className="text-gray-600">Sources Found</p>
              </div>
            </div>

            {/* Sources Table */}
            {results.sources.length > 0 && (
              <div className="bg-white rounded-xl shadow-lg p-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">
                  Similar Content Sources
                </h2>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-4 font-semibold text-gray-900">
                          Source
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-gray-900">
                          Similarity
                        </th>
                        <th className="text-left py-3 px-4 font-semibold text-gray-900">
                          Matched Text
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.sources.map((source: any, index: number) => (
                        <tr
                          key={index}
                          className="border-b border-gray-100 hover:bg-gray-50"
                        >
                          <td className="py-4 px-4">
                            <div>
                              <a
                                href={source.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:text-blue-700 font-medium text-sm cursor-pointer"
                              >
                                {source.title}
                              </a>
                              <p className="text-xs text-gray-500 mt-1">
                                {source.url}
                              </p>
                            </div>
                          </td>
                          <td className="py-4 px-4">
                            <span
                              className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                                source.similarity >= 20
                                  ? 'bg-red-100 text-red-800'
                                  : source.similarity >= 10
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : 'bg-green-100 text-green-800'
                              }`}
                            >
                              {source.similarity}%
                            </span>
                          </td>
                          <td className="py-4 px-4 text-gray-600 text-sm">
                            {source.matchedText.substring(0, 100)}...
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Improvement Suggestions */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Improvement Suggestions
              </h2>
              <div className="space-y-3">
                {results.suggestions.map((suggestion: string, index: number) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-teal-100 rounded-full flex items-center justify-center mt-0.5">
                      <i className="ri-lightbulb-line text-teal-600 text-sm"></i>
                    </div>
                    <p className="text-gray-700">{suggestion}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="text-center p-6">
            <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-global-line text-xl text-teal-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">
              Comprehensive Database
            </h3>
            <p className="text-sm text-gray-600">
              Search across billions of web pages and academic sources
            </p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-speed-line text-xl text-blue-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">
              Fast Results
            </h3>
            <p className="text-sm text-gray-600">
              Get detailed plagiarism report in seconds
            </p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-file-text-line text-xl text-purple-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">
              Multiple Formats
            </h3>
            <p className="text-sm text-gray-600">
              Support for text input and document upload
            </p>
          </div>
        </div>

        {/* Article Content */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Understanding Plagiarism Detection
          </h2>

          <div className="prose prose-lg max-w-none text-gray-700">
            <p className="mb-4">
              Plagiarism detection is crucial for maintaining content integrity
              and originality. Our advanced plagiarism checker helps writers,
              students, and professionals ensure their content is unique and
              properly attributed.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3 mt-8">
              Types of Plagiarism
            </h3>
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">
                  Direct Plagiarism
                </h4>
                <p className="text-sm text-gray-600 mb-4">
                  Word-for-word copying without attribution or quotation marks.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">
                  Paraphrasing Plagiarism
                </h4>
                <p className="text-sm text-gray-600 mb-4">
                  Rewording someone else's ideas without proper citation.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">
                  Mosaic Plagiarism
                </h4>
                <p className="text-sm text-gray-600 mb-4">
                  Mixing copied phrases with original content without
                  attribution.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">
                  Self-Plagiarism
                </h4>
                <p className="text-sm text-gray-600 mb-4">
                  Reusing your own previously published work without disclosure.
                </p>
              </div>
            </div>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              How Our Checker Works
            </h3>
            <ol className="list-decimal pl-6 mb-6">
              <li className="mb-2">
                Text is broken down into phrases and sentences
              </li>
              <li className="mb-2">
                Each segment is compared against our vast database
              </li>
              <li className="mb-2">
                Similar content is identified and sources are tracked
              </li>
              <li className="mb-2">
                A comprehensive report is generated with recommendations
              </li>
            </ol>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Best Practices for Original Content
            </h3>
            <div className="bg-teal-50 rounded-lg p-6 mb-6">
              <ul className="text-gray-700 space-y-2">
                <li className="flex items-start space-x-2">
                  <i className="ri-check-line text-teal-600 mt-0.5"></i>
                  <span>
                    <strong>Always cite your sources</strong> when referencing
                    other work
                  </span>
                </li>
                <li className="flex items-start space-x-2">
                  <i className="ri-check-line text-teal-600 mt-0.5"></i>
                  <span>
                    <strong>Use quotation marks</strong> for direct quotes
                  </span>
                </li>
                <li className="flex items-start space-x-2">
                  <i className="ri-check-line text-teal-600 mt-0.5"></i>
                  <span>
                    <strong>Paraphrase properly</strong> by completely
                    rewording and citing
                  </span>
                </li>
                <li className="flex items-start space-x-2">
                  <i className="ri-check-line text-teal-600 mt-0.5"></i>
                  <span>
                    <strong>Keep track of sources</strong> during research and
                    writing
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h2>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                How accurate is this plagiarism checker?
              </h3>
              <p className="text-gray-700">
                Our tool provides highly accurate results by scanning billions
                of web pages, academic papers, and published content to detect
                similarities.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Is my content stored or shared?
              </h3>
              <p className="text-gray-700">
                No, we respect your privacy. Your submitted content is only
                used for plagiarism checking and is not stored or shared with
                third parties.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                What percentage of similarity is acceptable?
              </h3>
              <p className="text-gray-700">
                Generally, less than 15% similarity is considered acceptable,
                but this varies by institution and content type. Always check
                your specific requirements.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Can I check multiple documents?
              </h3>
              <p className="text-gray-700">
                Yes, you can check multiple documents by using our tool multiple
                times. Each check is processed independently for accurate
                results.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                What file formats are supported?
              </h3>
              <p className="text-gray-700">
                Currently, we support plain text (.txt) file uploads and direct
                text input. Support for more formats is coming soon.
              </p>
            </div>
          </div>
        </div>

        {/* Related Tools */}
        <div className="bg-teal-50 rounded-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Related Content Tools
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/tools/backlink-checker" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-links-line text-blue-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">
                Backlink Checker
              </div>
            </Link>

            <Link href="/tools/meta-tags-extractor" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-code-line text-indigo-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">
                Meta Tags
              </div>
            </Link>

            <Link href="/tools/text-to-speech" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-volume-up-line text-orange-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">
                Text to Speech
              </div>
            </Link>

            <Link href="/tools" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-apps-line text-gray-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">
                All Tools
              </div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
