'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function PercentageCalculatorPage() {
  const [activeTab, setActiveTab] = useState('basic');
  
  // Basic percentage calculation
  const [basicValue, setBasicValue] = useState('');
  const [basicTotal, setBasicTotal] = useState('');
  const [basicResult, setBasicResult] = useState('');

  // Percentage increase/decrease
  const [oldValue, setOldValue] = useState('');
  const [newValue, setNewValue] = useState('');
  const [changeResult, setChangeResult] = useState('');
  const [changeType, setChangeType] = useState('');

  // Percentage of amount
  const [percentage, setPercentage] = useState('');
  const [amount, setAmount] = useState('');
  const [amountResult, setAmountResult] = useState('');

  // Tip calculator
  const [billAmount, setBillAmount] = useState('');
  const [tipPercent, setTipPercent] = useState('15');
  const [tipAmount, setTipAmount] = useState('');
  const [totalBill, setTotalBill] = useState('');

  const calculateBasicPercentage = () => {
    const value = parseFloat(basicValue);
    const total = parseFloat(basicTotal);
    
    if (!isNaN(value) && !isNaN(total) && total !== 0) {
      const result = (value / total) * 100;
      setBasicResult(result.toFixed(2));
    } else {
      setBasicResult('');
    }
  };

  const calculatePercentageChange = () => {
    const oldVal = parseFloat(oldValue);
    const newVal = parseFloat(newValue);
    
    if (!isNaN(oldVal) && !isNaN(newVal) && oldVal !== 0) {
      const change = ((newVal - oldVal) / oldVal) * 100;
      setChangeResult(Math.abs(change).toFixed(2));
      setChangeType(change >= 0 ? 'increase' : 'decrease');
    } else {
      setChangeResult('');
      setChangeType('');
    }
  };

  const calculatePercentageOfAmount = () => {
    const percent = parseFloat(percentage);
    const amt = parseFloat(amount);
    
    if (!isNaN(percent) && !isNaN(amt)) {
      const result = (percent / 100) * amt;
      setAmountResult(result.toFixed(2));
    } else {
      setAmountResult('');
    }
  };

  const calculateTip = () => {
    const bill = parseFloat(billAmount);
    const tip = parseFloat(tipPercent);
    
    if (!isNaN(bill) && !isNaN(tip)) {
      const tipAmt = (tip / 100) * bill;
      const total = bill + tipAmt;
      setTipAmount(tipAmt.toFixed(2));
      setTotalBill(total.toFixed(2));
    } else {
      setTipAmount('');
      setTotalBill('');
    }
  };

  const clearAll = () => {
    setBasicValue('');
    setBasicTotal('');
    setBasicResult('');
    setOldValue('');
    setNewValue('');
    setChangeResult('');
    setChangeType('');
    setPercentage('');
    setAmount('');
    setAmountResult('');
    setBillAmount('');
    setTipPercent('15');
    setTipAmount('');
    setTotalBill('');
  };

  const quickTipButtons = ['10', '15', '18', '20', '25'];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="ri-calculator-line text-2xl text-green-600"></i>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Percentage Calculator
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Calculate percentages, percentage increases, decreases, and solve all your percentage-related problems easily.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-xl shadow-lg p-2 mb-8">
          <div className="flex flex-wrap gap-1">
            {[
              { id: 'basic', label: 'Basic %', icon: 'ri-percent-line' },
              { id: 'change', label: 'Change %', icon: 'ri-line-chart-line' },
              { id: 'amount', label: '% of Amount', icon: 'ri-money-dollar-circle-line' },
              { id: 'tip', label: 'Tip Calculator', icon: 'ri-restaurant-line' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 px-4 py-3 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-green-600 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <i className={`${tab.icon} mr-2`}></i>
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Calculator Content */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          {/* Basic Percentage Calculator */}
          {activeTab === 'basic' && (
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                What percentage is X of Y?
              </h2>
              
              <div className="max-w-md mx-auto space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Value (X)
                  </label>
                  <input
                    type="number"
                    value={basicValue}
                    onChange={(e) => setBasicValue(e.target.value)}
                    onInput={calculateBasicPercentage}
                    placeholder="Enter value"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200 text-center text-xl"
                  />
                </div>

                <div className="text-center text-gray-500 font-medium">is what % of</div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Total Value (Y)
                  </label>
                  <input
                    type="number"
                    value={basicTotal}
                    onChange={(e) => setBasicTotal(e.target.value)}
                    onInput={calculateBasicPercentage}
                    placeholder="Enter total"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200 text-center text-xl"
                  />
                </div>

                {basicResult && (
                  <div className="text-center">
                    <div className="bg-green-100 rounded-xl p-6">
                      <div className="text-3xl font-bold text-green-600 mb-2">
                        {basicResult}%
                      </div>
                      <div className="text-green-800">
                        {basicValue} is {basicResult}% of {basicTotal}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Percentage Change Calculator */}
          {activeTab === 'change' && (
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Percentage Increase/Decrease
              </h2>
              
              <div className="max-w-md mx-auto space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Original Value
                  </label>
                  <input
                    type="number"
                    value={oldValue}
                    onChange={(e) => setOldValue(e.target.value)}
                    onInput={calculatePercentageChange}
                    placeholder="Enter original value"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200 text-center text-xl"
                  />
                </div>

                <div className="text-center text-gray-500 font-medium">changed to</div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    New Value
                  </label>
                  <input
                    type="number"
                    value={newValue}
                    onChange={(e) => setNewValue(e.target.value)}
                    onInput={calculatePercentageChange}
                    placeholder="Enter new value"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200 text-center text-xl"
                  />
                </div>

                {changeResult && (
                  <div className="text-center">
                    <div className={`rounded-xl p-6 ${
                      changeType === 'increase' ? 'bg-green-100' : 'bg-red-100'
                    }`}>
                      <div className={`text-3xl font-bold mb-2 ${
                        changeType === 'increase' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {changeType === 'increase' ? '+' : '-'}{changeResult}%
                      </div>
                      <div className={changeType === 'increase' ? 'text-green-800' : 'text-red-800'}>
                        {changeType === 'increase' ? 'Increase' : 'Decrease'} of {changeResult}%
                      </div>
                      <div className="text-gray-600 text-sm mt-2">
                        From {oldValue} to {newValue}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Percentage of Amount Calculator */}
          {activeTab === 'amount' && (
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                What is X% of Y?
              </h2>
              
              <div className="max-w-md mx-auto space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Percentage (%)
                  </label>
                  <input
                    type="number"
                    value={percentage}
                    onChange={(e) => setPercentage(e.target.value)}
                    onInput={calculatePercentageOfAmount}
                    placeholder="Enter percentage"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200 text-center text-xl"
                  />
                </div>

                <div className="text-center text-gray-500 font-medium">% of</div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Amount
                  </label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    onInput={calculatePercentageOfAmount}
                    placeholder="Enter amount"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200 text-center text-xl"
                  />
                </div>

                {amountResult && (
                  <div className="text-center">
                    <div className="bg-blue-100 rounded-xl p-6">
                      <div className="text-3xl font-bold text-blue-600 mb-2">
                        {amountResult}
                      </div>
                      <div className="text-blue-800">
                        {percentage}% of {amount} = {amountResult}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Tip Calculator */}
          {activeTab === 'tip' && (
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Tip Calculator
              </h2>
              
              <div className="max-w-md mx-auto space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Bill Amount
                  </label>
                  <input
                    type="number"
                    value={billAmount}
                    onChange={(e) => setBillAmount(e.target.value)}
                    onInput={calculateTip}
                    placeholder="Enter bill amount"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200 text-center text-xl"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Tip Percentage
                  </label>
                  <div className="flex gap-2 mb-3">
                    {quickTipButtons.map((tip) => (
                      <button
                        key={tip}
                        onClick={() => {
                          setTipPercent(tip);
                          calculateTip();
                        }}
                        className={`flex-1 py-2 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer ${
                          tipPercent === tip
                            ? 'bg-green-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {tip}%
                      </button>
                    ))}
                  </div>
                  <input
                    type="number"
                    value={tipPercent}
                    onChange={(e) => setTipPercent(e.target.value)}
                    onInput={calculateTip}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200 text-center text-xl"
                  />
                </div>

                {tipAmount && totalBill && (
                  <div className="space-y-4">
                    <div className="bg-green-100 rounded-xl p-6">
                      <div className="grid grid-cols-2 gap-4 text-center">
                        <div>
                          <div className="text-2xl font-bold text-green-600">
                            ${tipAmount}
                          </div>
                          <div className="text-green-800 text-sm">Tip Amount</div>
                        </div>
                        <div>
                          <div className="text-2xl font-bold text-green-600">
                            ${totalBill}
                          </div>
                          <div className="text-green-800 text-sm">Total Bill</div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="text-center text-gray-700 text-sm">
                        Bill: ${billAmount} + Tip ({tipPercent}%): ${tipAmount} = Total: ${totalBill}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Clear Button */}
          <div className="text-center mt-8">
            <button
              onClick={clearAll}
              className="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors font-medium whitespace-nowrap cursor-pointer"
            >
              <i className="ri-refresh-line mr-2"></i>
              Clear All
            </button>
          </div>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          <div className="text-center p-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-percent-line text-xl text-green-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Basic Percentage</h3>
            <p className="text-sm text-gray-600">Calculate what percentage X is of Y</p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-line-chart-line text-xl text-blue-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Change Percentage</h3>
            <p className="text-sm text-gray-600">Find percentage increase or decrease</p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-money-dollar-circle-line text-xl text-purple-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Amount Calculator</h3>
            <p className="text-sm text-gray-600">Calculate X% of any amount</p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-restaurant-line text-xl text-orange-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Tip Calculator</h3>
            <p className="text-sm text-gray-600">Calculate tips and total bill amount</p>
          </div>
        </div>

        {/* Usage Guide */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Percentage Calculator Guide
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Common Uses</h3>
              <div className="space-y-4">
                <div className="border border-gray-200 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Discounts & Sales</h4>
                  <p className="text-sm text-gray-600">
                    Calculate how much you save with percentage discounts during sales.
                  </p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Tax Calculations</h4>
                  <p className="text-sm text-gray-600">
                    Find the tax amount or total price including tax percentages.
                  </p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Grade & Scores</h4>
                  <p className="text-sm text-gray-600">
                    Convert test scores to percentages or calculate grade percentages.
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Calculation Tips</h3>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Basic Percentage:</p>
                    <p className="text-sm text-gray-600">(Value ÷ Total) × 100 = Percentage</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-arrow-up-line text-blue-600 text-sm"></i>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Percentage Increase:</p>
                    <p className="text-sm text-gray-600">((New - Old) ÷ Old) × 100</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-calculator-line text-purple-600 text-sm"></i>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Percentage of Amount:</p>
                    <p className="text-sm text-gray-600">(Percentage ÷ 100) × Amount</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-restaurant-line text-orange-600 text-sm"></i>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Tip Calculation:</p>
                    <p className="text-sm text-gray-600">Bill × (Tip% ÷ 100) + Bill</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* FAQ */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h2>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                How do I calculate a percentage of a number?
              </h3>
              <p className="text-gray-700">
                To find X% of a number, multiply the number by X and divide by 100. For example, 20% of 50 = (20 × 50) ÷ 100 = 10.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                What's the difference between percentage increase and decrease?
              </h3>
              <p className="text-gray-700">
                Percentage increase shows how much a value has grown, while percentage decrease shows how much it has shrunk, both relative to the original value.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                How do I calculate the original price before discount?
              </h3>
              <p className="text-gray-700">
                If you know the discounted price and discount percentage, divide the discounted price by (1 - discount percentage as decimal). For example, if 20% off results in $80, original price = $80 ÷ 0.8 = $100.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                What's a good tip percentage?
              </h3>
              <p className="text-gray-700">
                Standard tip percentages vary by service: 15-20% for restaurants, 10-15% for food delivery, 15-20% for hairdressers, and 10-20% for taxi drivers.
              </p>
            </div>
          </div>
        </div>

        {/* Related Tools */}
        <div className="bg-green-50 rounded-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Related Calculator Tools
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/tools/color-palette-generator" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-palette-line text-purple-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">Color Palette</div>
            </Link>

            <Link href="/tools/qr-generator" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-qr-code-line text-blue-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">QR Generator</div>
            </Link>

            <Link href="/tools/image-compressor" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-image-line text-orange-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">Image Tools</div>
            </Link>

            <Link href="/tools" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-apps-line text-gray-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">All Tools</div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}