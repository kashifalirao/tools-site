'use client';

import { useState } from 'react';
import Link from 'next/link';

interface ColorPalette {
  name: string;
  colors: string[];
  description: string;
}

export default function ColorPaletteGeneratorPage() {
  const [baseColor, setBaseColor] = useState('#3B82F6');
  const [paletteType, setPaletteType] = useState('complementary');
  const [palettes, setPalettes] = useState<ColorPalette[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const generatePalettes = () => {
    setIsGenerating(true);
    
    setTimeout(() => {
      const newPalettes: ColorPalette[] = [
        {
          name: 'Complementary',
          colors: [baseColor, '#F59E0B', '#10B981', '#EF4444', '#8B5CF6'],
          description: 'Colors opposite on the color wheel for high contrast'
        },
        {
          name: 'Analogous',
          colors: [baseColor, '#6366F1', '#8B5CF6', '#A855F7', '#C084FC'],
          description: 'Adjacent colors on the color wheel for harmony'
        },
        {
          name: 'Triadic',
          colors: [baseColor, '#EF4444', '#10B981', '#F59E0B', '#8B5CF6'],
          description: 'Three evenly spaced colors on the color wheel'
        },
        {
          name: 'Monochromatic',
          colors: ['#1E3A8A', baseColor, '#60A5FA', '#93C5FD', '#DBEAFE'],
          description: 'Different shades and tints of the same color'
        },
        {
          name: 'Split Complementary',
          colors: [baseColor, '#F59E0B', '#EF4444', '#EC4899', '#8B5CF6'],
          description: 'Base color plus two colors adjacent to its complement'
        },
        {
          name: 'Tetradic',
          colors: [baseColor, '#10B981', '#EF4444', '#F59E0B', '#8B5CF6'],
          description: 'Four colors arranged into two complementary pairs'
        }
      ];
      
      setPalettes(newPalettes);
      setIsGenerating(false);
    }, 1500);
  };

  const copyColor = (color: string) => {
    navigator.clipboard.writeText(color);
  };

  const copyPalette = (colors: string[]) => {
    const paletteText = colors.join(', ');
    navigator.clipboard.writeText(paletteText);
  };

  const exportPalette = (palette: ColorPalette) => {
    const cssContent = `/* ${palette.name} Color Palette */\n:root {\n${palette.colors.map((color, index) => `  --color-${index + 1}: ${color};`).join('\n')}\n}\n\n/* Usage Examples */\n.primary { color: var(--color-1); }\n.secondary { color: var(--color-2); }\n.accent { color: var(--color-3); }`;
    
    const blob = new Blob([cssContent], { type: 'text/css' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${palette.name.toLowerCase().replace(' ', '-')}-palette.css`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const presetColors = [
    '#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6',
    '#EC4899', '#06B6D4', '#84CC16', '#F97316', '#6366F1'
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-pink-100 to-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="ri-palette-line text-2xl text-purple-600"></i>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Color Palette Generator
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Generate beautiful color palettes for your design projects. Create harmonious color schemes using color theory principles.
          </p>
        </div>

        {/* Color Input */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="max-w-2xl mx-auto">
            <h3 className="text-lg font-semibold text-gray-900 mb-6 text-center">
              Choose Your Base Color
            </h3>
            
            <div className="flex flex-col items-center space-y-6">
              {/* Color Picker */}
              <div className="flex items-center space-x-4">
                <div 
                  className="w-20 h-20 rounded-xl shadow-lg cursor-pointer border-4 border-white"
                  style={{ backgroundColor: baseColor }}
                  onClick={() => document.getElementById('colorPicker')?.click()}
                ></div>
                <input
                  id="colorPicker"
                  type="color"
                  value={baseColor}
                  onChange={(e) => setBaseColor(e.target.value)}
                  className="hidden"
                />
                <div>
                  <input
                    type="text"
                    value={baseColor}
                    onChange={(e) => setBaseColor(e.target.value)}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 font-mono"
                    placeholder="#3B82F6"
                  />
                  <p className="text-sm text-gray-600 mt-1">Click color or enter hex code</p>
                </div>
              </div>

              {/* Preset Colors */}
              <div>
                <p className="text-sm font-medium text-gray-700 mb-3 text-center">Quick Select:</p>
                <div className="flex flex-wrap gap-3 justify-center">
                  {presetColors.map((color, index) => (
                    <button
                      key={index}
                      onClick={() => setBaseColor(color)}
                      className="w-10 h-10 rounded-lg shadow-md hover:scale-110 transition-transform cursor-pointer border-2 border-white"
                      style={{ backgroundColor: color }}
                    ></button>
                  ))}
                </div>
              </div>

              {/* Generate Button */}
              <button
                onClick={generatePalettes}
                disabled={isGenerating}
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-lg hover:from-purple-700 hover:to-pink-700 transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer"
              >
                {isGenerating ? 'Generating...' : 'Generate Palettes'}
              </button>
            </div>
          </div>
        </div>

        {/* Loading State */}
        {isGenerating && (
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8 text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-pink-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <div className="animate-spin w-8 h-8 border-2 border-purple-600 border-t-transparent rounded-full"></div>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Creating Color Palettes</h3>
            <p className="text-gray-600">Generating harmonious color combinations...</p>
          </div>
        )}

        {/* Generated Palettes */}
        {palettes.length > 0 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">
              Generated Color Palettes
            </h2>
            
            <div className="grid gap-6">
              {palettes.map((palette, paletteIndex) => (
                <div key={paletteIndex} className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="p-6">
                    <div className="flex justify-between items-center mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">{palette.name}</h3>
                        <p className="text-gray-600 text-sm">{palette.description}</p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => copyPalette(palette.colors)}
                          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium whitespace-nowrap cursor-pointer"
                        >
                          <i className="ri-file-copy-line mr-1"></i>
                          Copy
                        </button>
                        <button
                          onClick={() => exportPalette(palette)}
                          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm font-medium whitespace-nowrap cursor-pointer"
                        >
                          <i className="ri-download-line mr-1"></i>
                          CSS
                        </button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-5 gap-2 mb-4">
                      {palette.colors.map((color, colorIndex) => (
                        <div key={colorIndex} className="group">
                          <div
                            className="w-full h-20 rounded-lg shadow-md cursor-pointer hover:scale-105 transition-transform"
                            style={{ backgroundColor: color }}
                            onClick={() => copyColor(color)}
                          ></div>
                          <div className="text-center mt-2">
                            <p className="text-xs font-mono text-gray-700">{color}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Usage Examples */}
                    <div className="border-t border-gray-200 pt-4">
                      <p className="text-sm font-medium text-gray-700 mb-3">Usage Examples:</p>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="p-4 rounded-lg" style={{ backgroundColor: palette.colors[0], color: 'white' }}>
                          <h4 className="font-semibold">Primary</h4>
                          <p className="text-sm opacity-90">Main brand color</p>
                        </div>
                        <div className="p-4 rounded-lg" style={{ backgroundColor: palette.colors[1], color: 'white' }}>
                          <h4 className="font-semibold">Secondary</h4>
                          <p className="text-sm opacity-90">Supporting elements</p>
                        </div>
                        <div className="p-4 rounded-lg" style={{ backgroundColor: palette.colors[2], color: 'white' }}>
                          <h4 className="font-semibold">Accent</h4>
                          <p className="text-sm opacity-90">Call-to-action</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 my-12">
          <div className="text-center p-6">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-palette-line text-xl text-purple-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Multiple Schemes</h3>
            <p className="text-sm text-gray-600">
              Generate 6 different color harmony types based on color theory
            </p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-download-line text-xl text-green-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Export Options</h3>
            <p className="text-sm text-gray-600">
              Download CSS files or copy color codes instantly
            </p>
          </div>

          <div className="text-center p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-eye-line text-xl text-blue-600"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Live Preview</h3>
            <p className="text-sm text-gray-600">
              See how colors work together in real design examples
            </p>
          </div>
        </div>

        {/* Color Theory Guide */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Color Theory Guide
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Color Harmony Types</h3>
              <div className="space-y-4">
                <div className="border border-gray-200 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Complementary</h4>
                  <p className="text-sm text-gray-600">
                    Colors directly opposite each other on the color wheel. Creates high contrast and vibrant looks.
                  </p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Analogous</h4>
                  <p className="text-sm text-gray-600">
                    Colors that are next to each other on the color wheel. Creates serene and comfortable designs.
                  </p>
                </div>
                <div className="border border-gray-200 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Triadic</h4>
                  <p className="text-sm text-gray-600">
                    Three colors evenly spaced around the color wheel. Offers strong visual contrast while maintaining harmony.
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Design Tips</h3>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-lightbulb-line text-blue-600 text-sm"></i>
                  </div>
                  <p className="text-gray-700 text-sm">
                    Use the 60-30-10 rule: 60% dominant color, 30% secondary, 10% accent
                  </p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-eye-line text-green-600 text-sm"></i>
                  </div>
                  <p className="text-gray-700 text-sm">
                    Test your colors for accessibility and readability
                  </p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-smartphone-line text-purple-600 text-sm"></i>
                  </div>
                  <p className="text-gray-700 text-sm">
                    Consider how colors appear on different devices and screens
                  </p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-heart-line text-orange-600 text-sm"></i>
                  </div>
                  <p className="text-gray-700 text-sm">
                    Colors evoke emotions - choose based on your brand message
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* FAQ */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h2>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                How do I choose the right color palette for my project?
              </h3>
              <p className="text-gray-700">
                Consider your brand personality, target audience, and the emotions you want to evoke. Start with complementary colors for high contrast or analogous colors for harmony.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Can I use these color palettes commercially?
              </h3>
              <p className="text-gray-700">
                Yes, all generated color palettes are free to use for personal and commercial projects. Colors themselves cannot be copyrighted.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                How do I ensure my colors are accessible?
              </h3>
              <p className="text-gray-700">
                Use tools to check color contrast ratios. WCAG guidelines recommend a minimum contrast ratio of 4.5:1 for normal text and 3:1 for large text.
              </p>
            </div>
          </div>
        </div>

        {/* Related Tools */}
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Related Design Tools
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/tools/image-compressor" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-image-line text-orange-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">Image Compressor</div>
            </Link>

            <Link href="/tools/qr-generator" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-qr-code-line text-blue-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">QR Generator</div>
            </Link>

            <Link href="/tools/percentage-calculator" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-calculator-line text-green-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">Calculator</div>
            </Link>

            <Link href="/tools" className="bg-white p-4 rounded-lg hover:shadow-md transition-shadow text-center cursor-pointer">
              <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="ri-apps-line text-gray-600"></i>
              </div>
              <div className="text-sm font-medium text-gray-900">All Tools</div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}