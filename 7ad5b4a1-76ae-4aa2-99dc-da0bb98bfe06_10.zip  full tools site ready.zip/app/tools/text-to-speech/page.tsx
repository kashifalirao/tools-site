'use client';

import { useState, useRef } from 'react';
import Link from 'next/link';

export default function TextToSpeechPage() {
  const [text, setText] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState('female');
  const [speed, setSpeed] = useState(1);
  const [pitch, setPitch] = useState(1);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const synth = useRef<SpeechSynthesis | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useState(() => {
    if (typeof window !== 'undefined') {
      synth.current = window.speechSynthesis;
      
      const loadVoices = () => {
        const availableVoices = synth.current?.getVoices() || [];
        setVoices(availableVoices);
      };

      loadVoices();
      if (synth.current) {
        synth.current.onvoiceschanged = loadVoices;
      }
    }
  });

  const handleSpeak = () => {
    if (!text.trim()) return;

    if (synth.current) {
      if (isPlaying) {
        synth.current.cancel();
        setIsPlaying(false);
        return;
      }

      const utterance = new SpeechSynthesisUtterance(text);
      
      // Find voice based on selection
      const voice = voices.find(v => 
        selectedVoice === 'male' ? v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('david') : 
        v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('zira') || v.name.toLowerCase().includes('samantha')
      ) || voices[0];

      if (voice) utterance.voice = voice;
      utterance.rate = speed;
      utterance.pitch = pitch;

      utterance.onstart = () => setIsPlaying(true);
      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = () => setIsPlaying(false);

      utteranceRef.current = utterance;
      synth.current.speak(utterance);
    }
  };

  const handleStop = () => {
    if (synth.current) {
      synth.current.cancel();
      setIsPlaying(false);
    }
  };

  const handleDownload = () => {
    // Note: Browser speech synthesis doesn't support direct audio download
    // This would require a server-side solution or third-party API
    alert('Audio download feature requires a premium API service. Currently, you can only play the speech directly.');
  };

  const sampleTexts = [
    "Welcome to our text-to-speech tool. This is a sample text to test the speech functionality.",
    "The quick brown fox jumps over the lazy dog. This sentence contains every letter of the alphabet.",
    "Technology has revolutionized the way we communicate and interact with the world around us.",
    "Artificial intelligence and machine learning are shaping the future of digital innovation."
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Breadcrumb */}
        <div className="flex items-center space-x-2 text-sm text-gray-600 mb-6">
          <Link href="/" className="hover:text-blue-600">Home</Link>
          <i className="ri-arrow-right-s-line"></i>
          <Link href="/tools" className="hover:text-blue-600">Tools</Link>
          <i className="ri-arrow-right-s-line"></i>
          <span className="text-gray-900">Text to Speech</span>
        </div>

        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="ri-volume-up-line text-2xl text-orange-600"></i>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Text to Speech Converter
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Convert any text into natural-sounding speech with AI voices. Perfect for accessibility, learning, and content creation.
          </p>
        </div>

        {/* Tool Interface */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Input Section */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Enter Text to Convert
              </label>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Type or paste your text here..."
                className="w-full h-48 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 resize-none"
                maxLength={1000}
              />
              <div className="flex justify-between items-center mt-2">
                <span className="text-sm text-gray-500">{text.length}/1000 characters</span>
                <button
                  onClick={() => setText('')}
                  className="text-sm text-blue-600 hover:text-blue-700 cursor-pointer whitespace-nowrap"
                >
                  Clear Text
                </button>
              </div>

              {/* Sample Texts */}
              <div className="mt-4">
                <p className="text-sm font-medium text-gray-700 mb-2">Quick Samples:</p>
                <div className="space-y-2">
                  {sampleTexts.map((sample, index) => (
                    <button
                      key={index}
                      onClick={() => setText(sample)}
                      className="text-left text-sm text-gray-600 hover:text-blue-600 p-2 rounded border border-gray-200 hover:border-blue-300 transition-colors w-full cursor-pointer whitespace-nowrap"
                    >
                      {sample.substring(0, 80)}...
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Controls Section */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Voice Settings</h3>
              
              {/* Voice Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Voice Type</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setSelectedVoice('female')}
                    className={`p-3 rounded-lg border text-center transition-colors cursor-pointer whitespace-nowrap ${
                      selectedVoice === 'female' 
                        ? 'border-blue-500 bg-blue-50 text-blue-700' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <div className="w-8 h-8 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <i className="ri-women-line text-pink-600"></i>
                    </div>
                    Female Voice
                  </button>
                  <button
                    onClick={() => setSelectedVoice('male')}
                    className={`p-3 rounded-lg border text-center transition-colors cursor-pointer whitespace-nowrap ${
                      selectedVoice === 'male' 
                        ? 'border-blue-500 bg-blue-50 text-blue-700' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <i className="ri-men-line text-blue-600"></i>
                    </div>
                    Male Voice
                  </button>
                </div>
              </div>

              {/* Speed Control */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Speech Speed: {speed.toFixed(1)}x
                </label>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={speed}
                  onChange={(e) => setSpeed(parseFloat(e.target.value))}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>Slow</span>
                  <span>Normal</span>
                  <span>Fast</span>
                </div>
              </div>

              {/* Pitch Control */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Voice Pitch: {pitch.toFixed(1)}
                </label>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={pitch}
                  onChange={(e) => setPitch(parseFloat(e.target.value))}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>Low</span>
                  <span>Normal</span>
                  <span>High</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <button
                  onClick={handleSpeak}
                  disabled={!text.trim()}
                  className="w-full bg-orange-600 text-white py-3 px-6 rounded-lg hover:bg-orange-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2 whitespace-nowrap"
                >
                  <div className="w-5 h-5 flex items-center justify-center">
                    <i className={isPlaying ? 'ri-pause-line' : 'ri-play-line'}></i>
                  </div>
                  <span>{isPlaying ? 'Pause Speech' : 'Start Speaking'}</span>
                </button>

                <button
                  onClick={handleStop}
                  disabled={!isPlaying}
                  className="w-full border border-gray-300 text-gray-700 py-3 px-6 rounded-lg hover:bg-gray-50 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2 whitespace-nowrap"
                >
                  <div className="w-5 h-5 flex items-center justify-center">
                    <i className="ri-stop-line"></i>
                  </div>
                  <span>Stop</span>
                </button>

                <button
                  onClick={handleDownload}
                  disabled={!text.trim()}
                  className="w-full border border-orange-600 text-orange-600 py-3 px-6 rounded-lg hover:bg-orange-50 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2 whitespace-nowrap"
                >
                  <div className="w-5 h-5 flex items-center justify-center">
                    <i className="ri-download-line"></i>
                  </div>
                  <span>Download Audio</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-mic-line text-blue-600 text-xl"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Natural Voices</h3>
            <p className="text-gray-600 text-sm">High-quality AI voices that sound natural and clear</p>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-settings-line text-green-600 text-xl"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Customizable</h3>
            <p className="text-gray-600 text-sm">Adjust speed, pitch, and voice type to your preference</p>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-smartphone-line text-purple-600 text-xl"></i>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Works Everywhere</h3>
            <p className="text-gray-600 text-sm">Compatible with all modern browsers and devices</p>
          </div>
        </div>

        {/* Article Content */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">About Text to Speech Technology</h2>
          
          <div className="prose prose-gray max-w-none">
            <p className="text-gray-700 mb-4">
              Text-to-speech (TTS) technology has revolutionized the way we interact with digital content. Our free online text-to-speech converter uses advanced AI algorithms to transform written text into natural-sounding speech, making content more accessible and engaging for everyone.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-4 mt-8">Why Use Text to Speech?</h3>
            <ul className="list-disc pl-6 text-gray-700 space-y-2 mb-6">
              <li><strong>Accessibility:</strong> Perfect for visually impaired users or those with reading difficulties</li>
              <li><strong>Multitasking:</strong> Listen to content while doing other activities</li>
              <li><strong>Learning Aid:</strong> Helps with pronunciation and language learning</li>
              <li><strong>Content Creation:</strong> Create voiceovers for videos and presentations</li>
              <li><strong>Productivity:</strong> Review documents and articles hands-free</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-900 mb-4">Key Features of Our TTS Tool</h3>
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Voice Options</h4>
                <p className="text-gray-700 text-sm mb-4">Choose between male and female voices with different accents and tones to match your preference.</p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Speed Control</h4>
                <p className="text-gray-700 text-sm mb-4">Adjust playback speed from 0.5x to 2x to match your listening preference and comprehension needs.</p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Pitch Adjustment</h4>
                <p className="text-gray-700 text-sm mb-4">Fine-tune voice pitch to create the perfect sound for your content and audience.</p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Instant Playback</h4>
                <p className="text-gray-700 text-sm mb-4">No waiting time - your text is converted to speech instantly with high-quality output.</p>
              </div>
            </div>

            <h3 className="text-xl font-semibold text-gray-900 mb-4">Common Use Cases</h3>
            <p className="text-gray-700 mb-4">
              Our text-to-speech tool serves various purposes across different industries and personal needs:
            </p>
            <div className="bg-gray-50 rounded-lg p-6 mb-6">
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div>
                  <h5 className="font-semibold text-gray-900 mb-2">Education</h5>
                  <ul className="text-gray-600 space-y-1">
                    <li>• Language learning support</li>
                    <li>• Reading assistance</li>
                    <li>• Study material audio</li>
                  </ul>
                </div>
                <div>
                  <h5 className="font-semibold text-gray-900 mb-2">Business</h5>
                  <ul className="text-gray-600 space-y-1">
                    <li>• Presentation voiceovers</li>
                    <li>• Training materials</li>
                    <li>• Marketing content</li>
                  </ul>
                </div>
                <div>
                  <h5 className="font-semibold text-gray-900 mb-2">Content Creation</h5>
                  <ul className="text-gray-600 space-y-1">
                    <li>• Podcast narration</li>
                    <li>• Video voiceovers</li>
                    <li>• Audio books</li>
                  </ul>
                </div>
                <div>
                  <h5 className="font-semibold text-gray-900 mb-2">Personal Use</h5>
                  <ul className="text-gray-600 space-y-1">
                    <li>• Document review</li>
                    <li>• Email listening</li>
                    <li>• News consumption</li>
                  </ul>
                </div>
              </div>
            </div>

            <h3 className="text-xl font-semibold text-gray-900 mb-4">Tips for Better Results</h3>
            <div className="bg-blue-50 rounded-lg p-6 mb-6">
              <ul className="text-gray-700 space-y-2">
                <li className="flex items-start space-x-2">
                  <div className="w-5 h-5 flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-blue-600"></i>
                  </div>
                  <span><strong>Use proper punctuation</strong> - Periods, commas, and question marks help create natural pauses</span>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-5 h-5 flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-blue-600"></i>
                  </div>
                  <span><strong>Break long sentences</strong> - Shorter sentences are easier to understand when spoken</span>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-5 h-5 flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-blue-600"></i>
                  </div>
                  <span><strong>Avoid special characters</strong> - Stick to standard text for best pronunciation</span>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-5 h-5 flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-blue-600"></i>
                  </div>
                  <span><strong>Test different voices</strong> - Each voice may pronounce certain words differently</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* FAQ */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Is this text-to-speech tool completely free?</h3>
              <p className="text-gray-700">Yes, our text-to-speech converter is 100% free to use. There are no hidden charges, subscriptions, or limits on usage.</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">What's the maximum text length I can convert?</h3>
              <p className="text-gray-700">You can convert up to 1,000 characters at a time. For longer texts, simply break them into smaller chunks.</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Can I download the generated audio?</h3>
              <p className="text-gray-700">Currently, the browser-based version allows real-time playback. Audio download functionality requires premium API services which we're working to integrate.</p>
            </div>

            <div>
              <h3 className="text-lg font-semibential text-gray-900 mb-2">Which languages are supported?</h3>
              <p className="text-gray-700">The tool supports multiple languages based on your browser's speech synthesis capabilities. Most modern browsers support English, Spanish, French, German, and many other languages.</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Is my text data secure?</h3>
              <p className="text-gray-700">Yes, all text processing happens locally in your browser. We don't store or transmit your text data to any servers, ensuring complete privacy.</p>
            </div>
          </div>
        </div>

        {/* Related Tools */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Related Tools</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/tools/pdf-to-word" className="flex items-center space-x-3 p-4 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors cursor-pointer">
              <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                <i className="ri-file-pdf-line text-red-600"></i>
              </div>
              <div>
                <h4 className="font-medium text-gray-900">PDF to Word</h4>
                <p className="text-xs text-gray-600">Convert documents</p>
              </div>
            </Link>

            <Link href="/tools/plagiarism-checker" className="flex items-center space-x-3 p-4 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors cursor-pointer">
              <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                <i className="ri-shield-check-line text-teal-600"></i>
              </div>
              <div>
                <h4 className="font-medium text-gray-900">Plagiarism Checker</h4>
                <p className="text-xs text-gray-600">Check originality</p>
              </div>
            </Link>

            <Link href="/tools/qr-generator" className="flex items-center space-x-3 p-4 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors cursor-pointer">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <i className="ri-qr-code-line text-purple-600"></i>
              </div>
              <div>
                <h4 className="font-medium text-gray-900">QR Generator</h4>
                <p className="text-xs text-gray-600">Create QR codes</p>
              </div>
            </Link>

            <Link href="/tools" className="flex items-center space-x-3 p-4 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors cursor-pointer">
              <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                <i className="ri-apps-line text-gray-600"></i>
              </div>
              <div>
                <h4 className="font-medium text-gray-900">All Tools</h4>
                <p className="text-xs text-gray-600">View complete list</p>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}