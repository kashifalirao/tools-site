'use client';

import { useState, useRef } from 'react';
import Link from 'next/link';

export default function WordToPDFPage() {
  const [file, setFile] = useState<File | null>(null);
  const [isConverting, setIsConverting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [convertedFile, setConvertedFile] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (selectedFile: File) => {
    if (selectedFile && selectedFile.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      setFile(selectedFile);
      setConvertedFile(null);
    } else {
      alert('Please select a valid Word document (.docx)');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      handleFileSelect(droppedFile);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      handleFileSelect(selectedFile);
    }
  };

  const convertToPDF = async () => {
    if (!file) return;
    
    setIsConverting(true);
    setProgress(0);
    
    // Simulate conversion process
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + 10;
      });
    }, 200);

    // Simulate conversion delay
    setTimeout(() => {
      setProgress(100);
      setIsConverting(false);
      setConvertedFile(`${file.name.replace('.docx', '')}.pdf`);
      clearInterval(interval);
    }, 3000);
  };

  const downloadPDF = () => {
    if (!convertedFile) return;
    
    // Create a blob for demo purposes
    const demoContent = `Converted PDF: ${convertedFile}\\nOriginal Word file: ${file?.name}\\nConversion completed successfully!`;
    const blob = new Blob([demoContent], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = convertedFile;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const resetTool = () => {
    setFile(null);
    setConvertedFile(null);
    setIsConverting(false);
    setProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="ri-file-word-line text-3xl text-blue-600"></i>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Word to PDF Converter
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Convert Word documents to PDF format quickly and easily. Upload your .docx file and get a professional PDF in seconds.
          </p>
        </div>

        {/* Main Tool */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          {!convertedFile ? (
            <>
              {/* File Upload Area */}
              <div
                onDrop={handleDrop}
                onDragOver={(e) => e.preventDefault()}
                onDragEnter={(e) => e.preventDefault()}
                className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-blue-400 transition-colors"
              >
                {!file ? (
                  <div>
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-file-word-line text-2xl text-blue-600"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Select Word Document
                    </h3>
                    <p className="text-gray-600 mb-6">
                      Drag and drop your .docx file here, or click to browse
                    </p>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".docx"
                      onChange={handleFileInput}
                      className="hidden"
                      id="file-upload"
                    />
                    <label
                      htmlFor="file-upload"
                      className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer inline-block whitespace-nowrap"
                    >
                      Select Word File
                    </label>
                    <p className="text-sm text-gray-500 mt-4">
                      Supported format: .docx (Maximum file size: 10MB)
                    </p>
                  </div>
                ) : (
                  <div>
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-check-line text-2xl text-green-600"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      File Ready
                    </h3>
                    <p className="text-gray-600 mb-2">
                      {file.name}
                    </p>
                    <p className="text-sm text-gray-500 mb-6">
                      Size: {(file.size / (1024 * 1024)).toFixed(2)} MB
                    </p>
                    
                    {!isConverting ? (
                      <div className="flex justify-center space-x-4">
                        <button
                          onClick={convertToPDF}
                          className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors font-semibold whitespace-nowrap cursor-pointer"
                        >
                          <i className="ri-file-pdf-line mr-2"></i>
                          Convert to PDF
                        </button>
                        <button
                          onClick={resetTool}
                          className="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors font-semibold whitespace-nowrap cursor-pointer"
                        >
                          Choose Different File
                        </button>
                      </div>
                    ) : (
                      <div className="max-w-md mx-auto">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-gray-600">Converting...</span>
                          <span className="text-sm text-gray-600">{progress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-3">
                          <div
                            className="bg-blue-600 h-3 rounded-full transition-all duration-300"
                            style={{ width: `${progress}%` }}
                          ></div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </>
          ) : (
            /* Success State */
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-check-double-line text-3xl text-green-600"></i>
              </div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-4">
                Conversion Complete!
              </h3>
              <p className="text-gray-600 mb-8">
                Your Word document has been successfully converted to PDF format.
              </p>
              
              <div className="bg-gray-50 rounded-lg p-6 mb-8">
                <div className="flex items-center justify-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <i className="ri-file-word-line text-blue-600 text-xl"></i>
                    <span className="text-gray-700">{file?.name}</span>
                  </div>
                  <i className="ri-arrow-right-line text-gray-400"></i>
                  <div className="flex items-center space-x-2">
                    <i className="ri-file-pdf-line text-red-600 text-xl"></i>
                    <span className="text-gray-700">{convertedFile}</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-center space-x-4">
                <button
                  onClick={downloadPDF}
                  className="bg-green-600 text-white px-8 py-4 rounded-lg hover:bg-green-700 transition-colors font-semibold text-lg whitespace-nowrap cursor-pointer"
                >
                  <i className="ri-download-line mr-2"></i>
                  Download PDF
                </button>
                <button
                  onClick={resetTool}
                  className="bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition-colors font-semibold text-lg whitespace-nowrap cursor-pointer"
                >
                  Convert Another File
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-speed-line text-xl text-blue-600"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Fast Conversion</h3>
            <p className="text-gray-600">Convert Word documents to PDF in seconds with our optimized processing engine.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-shield-check-line text-xl text-green-600"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Secure & Private</h3>
            <p className="text-gray-600">Your files are processed securely and automatically deleted after conversion.</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <i className="ri-file-line text-xl text-purple-600"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">High Quality</h3>
            <p className="text-gray-600">Maintain original formatting, fonts, and layout in the converted PDF.</p>
          </div>
        </div>

        {/* Related Tools */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Related Tools</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link href="/tools/pdf-to-word" className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                  <i className="ri-file-pdf-line text-red-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">PDF to Word</div>
                  <div className="text-sm text-gray-600">Convert PDF to editable Word</div>
                </div>
              </div>
            </Link>
            <Link href="/tools/image-compressor" className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <i className="ri-image-line text-green-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Image Compressor</div>
                  <div className="text-sm text-gray-600">Compress images efficiently</div>
                </div>
              </div>
            </Link>
            <Link href="/tools/qr-generator" className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <i className="ri-qr-code-line text-purple-600"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">QR Generator</div>
                  <div className="text-sm text-gray-600">Create custom QR codes</div>
                </div>
              </div>
            </Link>
          </div>
        </div>

        {/* Article Content */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <article className="prose max-w-none">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">How to Convert Word to PDF Effectively</h2>
            
            <p className="text-lg text-gray-700 mb-6">
              Converting Word documents to PDF format is essential for document sharing, printing, and archival purposes. PDF format ensures your document looks the same across all devices and platforms, making it the preferred format for official documents, reports, and presentations.
            </p>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Why Convert Word to PDF?</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-blue-50 p-6 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-3">Document Security</h4>
                <ul className="space-y-2 text-blue-800 text-sm">
                  <li>• Prevents unauthorized editing</li>
                  <li>• Maintains original formatting</li>
                  <li>• Password protection option</li>
                  <li>• Digital signature support</li>
                </ul>
              </div>
              <div className="bg-green-50 p-6 rounded-lg">
                <h4 className="font-semibold text-green-900 mb-3">Universal Compatibility</h4>
                <ul className="space-y-2 text-green-800 text-sm">
                  <li>• Works on all devices</li>
                  <li>• Consistent appearance</li>
                  <li>• Professional presentation</li>
                  <li>• Easy sharing and printing</li>
                </ul>
              </div>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Step-by-Step Conversion Guide</h3>
            <div className="space-y-4 mb-8">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold text-sm">1</div>
                <div>
                  <h4 className="font-semibold text-gray-900">Upload Your Word Document</h4>
                  <p className="text-gray-600">Select your .docx file by clicking the upload button or drag and drop it into the designated area.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold text-sm">2</div>
                <div>
                  <h4 className="font-semibold text-gray-900">Start Conversion</h4>
                  <p className="text-gray-600">Click the "Convert to PDF" button and wait for the processing to complete. This usually takes just a few seconds.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold text-sm">3</div>
                <div>
                  <h4 className="font-semibold text-gray-900">Download Your PDF</h4>
                  <p className="text-gray-600">Once conversion is complete, click the download button to save your PDF file to your device.</p>
                </div>
              </div>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Best Practices</h3>
            <div className="bg-gray-50 p-6 rounded-lg mb-6">
              <ul className="space-y-3">
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Review your Word document before conversion to ensure proper formatting</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Use standard fonts for better compatibility across devices</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Optimize images in your Word document for smaller PDF file size</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <i className="ri-check-line text-green-600 text-sm"></i>
                  </div>
                  <span className="text-gray-700">Check page breaks and layouts before conversion</span>
                </li>
              </ul>
            </div>

            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Frequently Asked Questions</h3>
            <div className="space-y-6">
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">Is the Word to PDF conversion free?</h4>
                <p className="text-gray-700">Yes, our Word to PDF converter is completely free to use with no hidden costs or limitations.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">What file formats are supported?</h4>
                <p className="text-gray-700">We currently support .docx (Microsoft Word 2007 and later) format for conversion to PDF.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">Are my documents secure?</h4>
                <p className="text-gray-700">Yes, all uploaded files are processed securely and automatically deleted from our servers after conversion.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-2">What is the maximum file size?</h4>
                <p className="text-gray-700">You can upload Word documents up to 10MB in size for conversion to PDF.</p>
              </div>
            </div>
          </article>
        </div>
      </div>
    </div>
  );
}